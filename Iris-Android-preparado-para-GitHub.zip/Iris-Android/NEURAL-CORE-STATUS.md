# IRIS Neural Core — integração segura (preparação)

## Estado real
- A interface, as respostas locais, as notas e a base SQLite anteriores foram mantidas.
- Foi adicionada uma fronteira `IrisNeuralCore` que permite futuramente ligar um mecanismo GGUF local.
- **Ainda não há inferência neural.** `generateOrNull()` retorna `null` e o aplicativo continua usando as respostas anteriores.
- **Os pesos Qwen3 1.7B não estão incluídos.** Não houve acesso à rede para obtê-los e verificar hash/licença.
- **Não foi compilado nem testado em Android** neste ambiente.

## Próximas etapas necessárias
1. Obter uma variante GGUF Q4 do Qwen3 1.7B de fonte confiável, conferir a licença e registrar SHA-256.
2. Integrar e compilar um runtime nativo como llama.cpp para Android arm64-v8a, com ABI, JNI, CMake e NDK adequados.
3. Implementar carregamento, tokenização, template de chat Qwen3, streaming de tokens, interrupção e limites de memória.
4. Fazer inferência fora da thread de UI; controlar estado do modelo e mostrar erros reais.
5. Testar no aparelho com 8 GB RAM, inclusive reinicialização, histórico, notas, voz, desempenho e uso offline.
6. Empacotar os pesos conforme limites e regras de distribuição Android; não presumir que um APK único de vários GB será aceito.

## Proteção dos dados
O identificador de aplicativo e o nome `iris_local.db` não foram alterados. A atualização não inclui migração destrutiva de banco nem exclusão de mensagens. Faça backup antes de instalar qualquer APK novo.
