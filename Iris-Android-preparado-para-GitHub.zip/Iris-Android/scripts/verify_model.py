#!/usr/bin/env python3
"""Verifica o cabeçalho GGUF, tamanho e SHA-256; não executa inferência."""
import hashlib, pathlib, sys
if len(sys.argv) != 2:
    sys.exit('Uso: python3 scripts/verify_model.py /caminho/modelo.gguf')
p = pathlib.Path(sys.argv[1])
if not p.is_file():
    sys.exit('Arquivo não encontrado')
with p.open('rb') as f:
    if f.read(4) != b'GGUF':
        sys.exit('ERRO: assinatura GGUF inválida')
if p.stat().st_size < 500_000_000:
    sys.exit('ERRO: arquivo muito pequeno para o modelo esperado')
h = hashlib.sha256()
with p.open('rb') as f:
    for block in iter(lambda: f.read(4*1024*1024), b''):
        h.update(block)
print('GGUF encontrado; bytes:', p.stat().st_size)
print('SHA-256:', h.hexdigest())
print('ATENÇÃO: isso não prova compatibilidade ou integridade frente ao hash oficial.')
