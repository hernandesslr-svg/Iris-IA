# Iris Android — primeira migração nativa (protótipo)

Este é um **projeto Android Kotlin nativo**, sem WebView, Python ou servidor local.

## O que já foi implementado
- Interface de chat Android com histórico em SQLite no aparelho.
- Respostas offline básicas e **parte das respostas temáticas extraídas do código original** (`app/src/main/assets/topics.json`).
- Comandos locais de hora, data e notas.
- Integração com TextToSpeech e reconhecimento de voz disponibilizados pelo Android (o reconhecimento pode depender de serviço/rede do aparelho).

## Ainda não foi migrado
- O classificador Naive Bayes e o gerador de trigramas originais (arquivos TypeScript não rodam neste projeto Kotlin).
- Pesquisa web, clima, autenticação, recursos avançados da interface original e equivalência funcional integral.
- Não há APK compilado nem teste em aparelho. Este é um ponto de partida funcional em código, **não uma conversão concluída**.

## Compilar
Abra a pasta `Iris-Android` no Android Studio, com Android SDK 35 e JDK 17, aguarde o Gradle sincronizar e execute `Build > Build APK(s)`. O projeto exige Android 8.0+ (API 26). A configuração Gradle usa Android Gradle Plugin 8.7.3 e Kotlin 2.0.21.

## Arquivos de referência
`referencia-original/` contém os arquivos principais do mecanismo de linguagem original para a próxima etapa de migração. O código original completo permanece no ZIP enviado pelo usuário.

## Atualização 0.2 — mecanismo original de linguagem
- Adicionado `IrisLanguageEngine.kt`: porta nativa do classificador Naive Bayes (assunto/humor) e do gerador de trigramas, usando os pesos originais em `assets/iris-lm-weights.json`.
- Mantidos o fluxo de chat, SQLite, notas, comandos de hora/data, voz e respostas temáticas anteriores. Caso o motor não carregue ou não gere uma resposta completa, as respostas anteriores continuam disponíveis.
- A geração é aproximada: esta versão ainda não reproduz todas as validações, estágios de conversa e personalização da implementação TypeScript original.
- Pesquisa web, clima, autenticação e interface web original **não foram migrados**. Não foram adicionadas dependências de rede, WebView ou servidores.
- **Validação pendente:** ambiente atual sem SDK Android/Gradle, portanto não foi possível executar build, testes instrumentados ou testar o APK em dispositivo. Faça backup do APK que já funciona e instale esta versão apenas depois de compilar e testar em ambiente Android.
