package com.iris.assistant

import android.content.Context
import java.io.File

/**
 * Non-destructive integration boundary for a future on-device GGUF inference runtime.
 * No network calls, no implicit model downloads, and no pretend generated responses.
 * The existing local response engine remains operational until inference is validated.
 */
class IrisNeuralCore(private val context: Context) {
    companion object {
        const val MODEL_FILENAME = "qwen3-1.7b-q4.gguf"
        const val MIN_MODEL_BYTES = 500_000_000L
    }

    val modelFile: File get() = File(context.filesDir, "models/$MODEL_FILENAME")

    fun status(): Status {
        val file = modelFile
        if (!file.isFile) return Status.MODEL_MISSING
        if (file.length() < MIN_MODEL_BYTES) return Status.MODEL_INVALID
        return Status.RUNTIME_NOT_INSTALLED
    }

    /** Returns null until a tested native inference runtime is installed. */
    fun generateOrNull(prompt: String): String? {
        require(prompt.length <= 100_000) { "Prompt muito grande" }
        return null
    }

    enum class Status { MODEL_MISSING, MODEL_INVALID, RUNTIME_NOT_INSTALLED }
}
