package com.iris.assistant

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import java.text.Normalizer
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var db: ChatStore
    private lateinit var neural: IrisNeuralCore
    private lateinit var feed: LinearLayout
    private lateinit var entry: EditText
    private var tts: TextToSpeech? = null
    private var speechReady = false
    private var topics = JSONArray()
    private var languageEngine: IrisLanguageEngine? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ChatStore()
        neural = IrisNeuralCore(this)
        topics = JSONArray(assets.open("topics.json").bufferedReader().use { it.readText() })
        languageEngine = try { IrisLanguageEngine(this) } catch (_: Exception) { null }
        tts = TextToSpeech(this, this)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247,249,252)) }
        val title = TextView(this).apply { text = "✦  Iris"; textSize = 25f; setTextColor(Color.rgb(17,85,180)); setTypeface(null,Typeface.BOLD); setPadding(22,28,12,20) }
        page.addView(title)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        feed = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,8,16,8) }
        scroll.addView(feed)
        page.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,14) }
        entry = EditText(this).apply { hint = "Converse com a Iris..."; setSingleLine(false); maxLines=3 }
        bottom.addView(entry,LinearLayout.LayoutParams(0,-2,1f))
        val send = Button(this).apply { text="Enviar"; setOnClickListener { val msg=entry.text.toString().trim(); if(msg.isNotEmpty()){ entry.setText(""); addMessage("Você",msg); val answer=neural.generateOrNull(msg) ?: respond(msg); addMessage("Iris",answer); if(speechReady) tts?.speak(answer,TextToSpeech.QUEUE_FLUSH,null,"iris") ;scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } } } }
        bottom.addView(send)
        val mic = Button(this).apply { text="🎙"; contentDescription="Falar"; setOnClickListener { try { startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR") },100) } catch(e:Exception){ Toast.makeText(this@MainActivity,"Reconhecimento de voz indisponível neste aparelho",Toast.LENGTH_LONG).show() } } }
        bottom.addView(mic)
        page.addView(bottom)
        setContentView(page)
        db.read().forEach { (role,text)-> showMessage(role,text) }
        if(feed.childCount==0) showMessage("Iris","Olá! Sou a Iris. Posso conversar, guardar notas e responder a comandos básicos offline.")
    }
    private fun addMessage(role:String, message:String) { db.save(role,message); showMessage(role,message) }
    private fun showMessage(role:String, message:String) {
        val bubble = TextView(this).apply { text="$role\n$message"; textSize=16f; setTextColor(Color.rgb(26,35,48)); setPadding(18,14,18,14); setBackgroundColor(if(role=="Iris") Color.rgb(229,237,249) else Color.rgb(216,235,252)) }
        val lp=LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,12) }
        feed.addView(bubble,lp)
    }
    private fun normalize(s:String)=Normalizer.normalize(s.lowercase(Locale.ROOT),Normalizer.Form.NFD).replace(Regex("\\p{M}+"),"")
    private fun respond(input:String):String {
        val n=normalize(input).trim()
        if(n.matches(Regex("^(oi|ola|bom dia|boa tarde|boa noite|ei iris)[!. ]*$"))) return "Oi! Estou aqui. Sobre o que vamos conversar?"
        if(n.contains("que horas") || n.contains("hora agora")) return "Agora são ${java.text.SimpleDateFormat("HH:mm",Locale("pt","BR")).format(java.util.Date())}."
        if(n.contains("que dia") || n.contains("data de hoje")) return "Hoje é ${java.text.SimpleDateFormat("dd/MM/yyyy",Locale("pt","BR")).format(java.util.Date())}."
        if(n.startsWith("anota ") || n.startsWith("anote ")) { val note=input.substringAfter(' ').trim(); db.note(note); return "Anotei: $note" }
        if(n.contains("minhas notas") || n.contains("meus lembretes")) { val notes=db.notes(); return if(notes.isEmpty()) "Você ainda não tem notas." else notes.joinToString("\n") }
        if(n.contains("suas capacidades") || n.contains("o que voce faz")) return "Consigo conversar sobre assuntos conhecidos, guardar notas, informar hora e data e usar voz quando o Android disponibiliza o serviço. Estou funcionando localmente."
        languageEngine?.reply(input)?.let { return it }
        for(i in 0 until topics.length()) {
            val topic=topics.getJSONObject(i)
            try { if(Regex(topic.getString("regex")).containsMatchIn(n)) {
                val answers=topic.getJSONArray("responses")
                val questions=topic.getJSONArray("questions")
                val idx=(System.currentTimeMillis()/1000L % answers.length()).toInt()
                val q=(System.currentTimeMillis()/1000L % questions.length()).toInt()
                return answers.getString(idx).replace("{c}","você")+" "+questions.getString(q)
            } } catch (_:Exception) { }
        }
        return "Quero entender melhor. Você pode me contar mais sobre isso?"
    }
    override fun onInit(status:Int) { if(status==TextToSpeech.SUCCESS) speechReady=tts?.setLanguage(Locale("pt","BR")) != TextToSpeech.LANG_MISSING_DATA }
    @Deprecated("Android speech activity callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==100 && resultCode==RESULT_OK){ val heard=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull(); if(heard!=null) entry.setText(heard) } }
    override fun onDestroy(){ tts?.shutdown(); db.close(); super.onDestroy() }
    inner class ChatStore:SQLiteOpenHelper(this@MainActivity,"iris_local.db",null,1) {
        override fun onCreate(d:SQLiteDatabase){ d.execSQL("CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT,role TEXT NOT NULL,body TEXT NOT NULL)"); d.execSQL("CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT,body TEXT NOT NULL)") }
        override fun onUpgrade(d:SQLiteDatabase,old:Int,new:Int){}
        fun save(role:String,body:String){ writableDatabase.execSQL("INSERT INTO messages(role,body) VALUES (?,?)",arrayOf(role,body)) }
        fun note(body:String){ writableDatabase.execSQL("INSERT INTO notes(body) VALUES (?)",arrayOf(body)) }
        fun read():List<Pair<String,String>> { val result= mutableListOf<Pair<String,String>>(); readableDatabase.rawQuery("SELECT role,body FROM messages ORDER BY id",null).use { while(it.moveToNext()) result.add(it.getString(0) to it.getString(1)) };return result }
        fun notes():List<String>{ val result=mutableListOf<String>(); readableDatabase.rawQuery("SELECT body FROM notes ORDER BY id",null).use { while(it.moveToNext()) result.add(it.getString(0)) };return result }
    }
}
