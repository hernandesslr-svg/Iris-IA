package com.iris.assistant

import android.content.Context
import org.json.JSONObject
import org.json.JSONArray
import java.text.Normalizer
import java.util.Locale
import kotlin.math.ln
import kotlin.random.Random

/** Port of the original Iris Naive Bayes classifier and trigram sampler. Offline only. */
class IrisLanguageEngine(context: Context) {
    private val root = JSONObject(context.assets.open("iris-lm-weights.json").bufferedReader().use { it.readText() })
    private val gen = root.getJSONObject("gen")
    private val vocab = gen.getJSONArray("vocab")
    private val tables = gen.getJSONObject("tables")
    data class Guess(val label: String, val known: Int, val gap: Double, val confident: Boolean)
    private fun norm(s: String): String = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    private fun features(text: String): Set<String> {
        val tokens = norm(text).split(Regex("[^a-z0-9]+" )).filter { it.isNotEmpty() }
        val out = linkedSetOf<String>()
        for ((i, token) in tokens.withIndex()) {
            if (token.length >= 2) out.add("w:$token")
            if (i + 1 < tokens.size) out.add("b:${token}_${tokens[i+1]}")
            if (token.length >= 4) {
                val w = "^$token$"
                for (size in 4..5) for (at in 0..w.length-size) out.add("c:${w.substring(at,at+size)}")
            }
        }
        return out
    }
    fun classify(text: String, name: String): Guess {
        val model = root.getJSONObject(name)
        val classes = model.getJSONArray("classes")
        val prior = model.getJSONArray("prior")
        val totals = model.getJSONArray("total")
        val feats = model.getJSONObject("feats")
        val alpha = model.getDouble("alpha")
        val vocabSize = model.getInt("vocab")
        val scores = DoubleArray(classes.length()) { prior.getDouble(it) }
        var known = 0
        for (f in features(text)) {
            val row = feats.optJSONArray(f) ?: continue
            known++
            val counts = DoubleArray(scores.size)
            var j=0
            while (j+1 < row.length()) { counts[row.getInt(j)] = row.getDouble(j+1); j+=2 }
            for (c in scores.indices) scores[c] += ln((counts[c]+alpha)/(totals.getDouble(c)+alpha*vocabSize))
        }
        val order = scores.indices.sortedByDescending { scores[it] }
        val gap = if (known>0 && order.size>1) (scores[order[0]]-scores[order[1]])/known else 0.0
        return Guess(classes.getString(order.first()), known, gap, known>=3 && gap>=model.getDouble("minGap"))
    }
    private fun mergedRow(keys: List<Pair<String, Int>>, a:Int, b:Int): Map<Int,Int> {
        for (order in listOf("o3","o2")) {
            val merged = sortedMapOf<Int,Int>()
            for ((key, weight) in keys) {
                val table=tables.optJSONObject(key) ?: continue
                val row=table.getJSONObject(order).optJSONArray(if(order=="o3") "$a,$b" else "$b") ?: continue
                var i=0
                while(i+1<row.length()) { val id=row.getInt(i); merged[id]=(merged[id]?:0)+row.getInt(i+1)*weight; i+=2 }
            }
            if(merged.isNotEmpty()) return merged
        }
        return emptyMap()
    }
    private fun generate(keys:List<Pair<String,Int>>, seed:Int, maxSentences:Int):String {
        val rng=Random(seed)
        val out= mutableListOf<String>()
        var a=0; var b=0; var done=0
        repeat(34) {
            val row=mergedRow(keys,a,b)
            if(row.isEmpty()) return ""
            var pick=rng.nextInt(row.values.sum())
            var next=row.keys.last()
            for ((id,weight) in row) { pick-=weight; if(pick<0) { next=id; break } }
            if(next==1) return detokenize(out)
            val token=vocab.getString(next)
            out.add(token)
            if(token in listOf(".","?","!")) { done++; if(done>=maxSentences) return detokenize(out) }
            a=b; b=next
        }
        return ""
    }
    private fun detokenize(tokens:List<String>):String {
        val sb=StringBuilder()
        for(t in tokens) { if(sb.isNotEmpty() && t !in listOf(".",",","!","?",";",":","…")) sb.append(' '); sb.append(t) }
        return sb.toString()
    }
    /** Uses the original topic/mood weights and generation tables; rejects incomplete output. */
    fun reply(input:String):String? {
        val topic=classify(input,"topic")
        val mood=classify(input,"mood")
        val t=if(topic.confident && topic.label!="geral") topic.label else "*"
        val m=if(mood.confident) mood.label else "neu"
        val seed=input.hashCode()
        val reactionKeys=listOf("R:$t:$m" to 3,"R:*:$m" to 1)
        val questionKeys=listOf("Q:$t:ask" to 3,"Q:*:ask:$m" to 1)
        for(i in 0..15) {
            val reaction=generate(reactionKeys,seed+i*7919,2)
            val question=generate(questionKeys,seed+i*7919+97,1)
            if(reaction.length in 8..190 && question.length in 8..190 && reaction.lastOrNull() in listOf('.','!','?') && question.lastOrNull() in listOf('.','!','?') && !reaction.contains('{') && !question.contains('{')) return "$reaction $question"
        }
        return null
    }
}
