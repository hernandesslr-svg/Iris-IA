# Iris Android — pacote preparado para envio ao GitHub

## O que está pronto
- Código-fonte Kotlin original preservado, sem mudar `applicationId` nem o banco SQLite.
- `.gitignore` bloqueia modelos GGUF, pesos Safetensors, APKs e saídas de compilação.
- Workflow GitHub Actions para compilar o protótipo Android **sem modelo neural**, após enviar o projeto para o GitHub.
- `scripts/verify_model.py` verifica assinatura GGUF, tamanho e calcula SHA-256 localmente.

## O que ainda NÃO está pronto
- **Não há runtime de inferência GGUF ligado ao aplicativo**: `IrisNeuralCore.generateOrNull()` ainda retorna null.
- O Qwen3 1.7B não está incluído e não foi baixado.
- Não houve compilação Android ou testes no celular. O workflow ainda precisa ser executado e eventuais erros corrigidos.
- O workflow **não** produz um APK neural e não baixa modelos; isso seria enganoso sem um runtime real e estratégia de empacotamento validada.

## Caminho de implementação
1. Integrar biblioteca llama.cpp para Android ARM64 via JNI/CMake (ou runtime Android equivalente).
2. Executar geração em thread de trabalho, com cancelamento, contexto, template Qwen3 e tratamento de erros.
3. Escolher um GGUF Q4_K_M compatível, verificar origem/licença e SHA-256.
4. Empacotar ou provisionar os pesos com uma estratégia que respeite os limites do Android e a exigência de instalação offline.
5. Compilar, testar no Galaxy com 8 GB de RAM, verificar histórico, voz e resposta real do modelo.

**Não substitua a versão funcional instalada por este protótipo.**
