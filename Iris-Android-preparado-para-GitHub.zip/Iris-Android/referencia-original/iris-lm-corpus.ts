/**
 * Texto de treino do modelo da Iris. Tudo escrito para ela, em português do Brasil.
 * Quanto mais exemplos entrarem aqui, mais ela aprende: depois é só rodar `npm run train:lm`.
 */

/** Palavras-chave de cada assunto (viram exemplos de treino em várias frases-molde). */
export const TOPIC_WORDS: Record<string, string> = {
  ansiedade: "ansiedade ansioso nervosismo estresse estressante pressão tensão angústia aflição pânico preocupação sobrecarga",
  emocoes: "choro paciência desânimo desmotivação vergonha culpa insegurança autoestima decepção frustração apatia sem rumo",
  solidao: "solidão sozinho isolamento abandono vazio ninguém isolada carência",
  correria: "correria agitação pressa sem tempo atropelo cansaço da rotina dia cheio compromissos agenda lotada",
  saudade: "saudade nostalgia lembrança infância antigamente recordação passado velhos tempos",
  objetivos: "sonho meta objetivo futuro planos carreira projeto ambição propósito aspiração",
  politica: "política eleição governo partido votar deputado presidente corrupção congresso impostos",
  religiao: "fé igreja oração deus religião missa espiritualidade culto bíblia terreiro templo",
  filosofia: "sentido da vida felicidade destino tempo existência liberdade morte valores sabedoria mudança",
  estudo: "prova faculdade escola estudar aula professor nota concurso vestibular trabalho escolar matéria curso tcc",
  trabalho: "trabalho emprego chefe reunião colega empresa salário expediente cliente projeto entrevista plantão",
  namoro: "namorado namorada crush paixão relacionamento término ciúmes encontro casamento ficante beijo",
  familia: "mãe pai irmão irmã avó avô tio tia primo filho filha sogra marido esposa",
  amizade: "amigo amiga amizade turma galera parceiro colega convite rolê reencontro",
  saude: "gripe febre médico consulta exame remédio dor hospital dentista cirurgia machucado alergia tosse",
  sono: "sono dormir insônia pesadelo acordar cochilo madrugada cansado descanso cama sonhei",
  dinheiro: "dinheiro dívida fatura aluguel boleto salário economia investimento cartão conta gastos grana",
  comida: "fome almoço jantar café pizza lanche sobremesa receita restaurante churrasco doce dieta cozinhar",
  esporte: "futebol treino academia corrida time jogo campeonato natação basquete vôlei maratona ciclismo",
  musica: "música cantor banda show álbum playlist violão guitarra piano canção festival ritmo",
  filmes: "filme série cinema netflix anime episódio temporada documentário novela maratona estreia",
  jogos: "videogame jogo partida fase console xadrez truco rpg minecraft campeonato online",
  viagem: "viagem férias passagem aeroporto hotel praia mochila estrada feriado passeio destino turismo",
  pets: "cachorro gato bichinho filhote veterinário ração coleira passarinho adoção patinhas",
  casa: "casa apartamento reforma mudança vizinho quarto faxina bagunça móveis condomínio decoração",
  compras: "compra loja shopping promoção entrega pedido desconto presente roupa mercado carrinho",
  transporte: "trânsito ônibus metrô carro moto uber bicicleta atraso engarrafamento habilitação gasolina estacionamento",
  festa: "aniversário festa balada churrasco formatura natal carnaval réveillon bolo comemoração convidados",
  hobbies: "leitura livro desenho pintura fotografia jardim horta croché poesia escrever yoga dança artesanato",
  aparencia: "tatuagem cabelo barba maquiagem unha visual espelho balança peso corte roupa nova",
  tecnologia: "celular computador wifi aplicativo programação bug notebook internet teclado atualização sistema",
  idiomas: "inglês espanhol francês idioma sotaque duolingo fluente vocabulário gramática tradução",
  clima: "chuva calor frio vento tempestade nublado sol garoa abafado friozinho céu",
  rotina: "rotina segunda sexta domingo sábado folga fim de semana preguiça manhã descanso hábito",
  ciencia: "astronomia planeta estrela galáxia dinossauro oceano biologia física química evolução universo",
};

/** Frases-molde para transformar palavra-chave em exemplo. */
export const FRAMES = [
  "tô com {w}",
  "hoje tive {w}",
  "estou pensando em {w}",
  "falei sobre {w} hoje",
  "{w} tomou conta do meu dia",
  "queria conversar sobre {w}",
  "o assunto de hoje é {w}",
  "gosto muito de {w}",
  "ando preocupado com {w}",
  "não paro de pensar em {w}",
];

/** Frases naturais de cada assunto (para o modelo aprender o jeito de falar, além das palavras soltas). */
export const TOPIC_SENTENCES: Record<string, string[]> = {
  ansiedade: ["meu peito fica apertado quando penso no amanhã", "não consigo relaxar, minha cabeça não desliga", "tô num estado de alerta o dia todo", "sinto um nó no estômago antes de qualquer coisa", "ando com a cabeça cheia e o coração acelerado"],
  emocoes: ["hoje eu só queria sumir do mundo um pouco", "me sinto sem energia pra nada", "chorei escondido no banheiro", "tô sem paciência com todo mundo", "sinto que tô perdido sem saber o que quero"],
  solidao: ["passei o fim de semana sem falar com ninguém", "não tem ninguém para eu chamar quando preciso", "a casa parece grande e silenciosa demais", "sinto que ninguém percebe que eu existo", "quase não converso com pessoas ultimamente"],
  correria: ["não paro um segundo desde cedo", "minha semana tá um atropelo só", "falta hora no dia para tanta coisa", "mal consigo sentar para comer direito", "preciso de uma pausa urgente na agenda"],
  saudade: ["bateu uma vontade enorme de voltar ao interior", "lembrei das férias na casa da vovó", "sinto falta de como as coisas eram antes", "vi uma foto antiga e fiquei mexido", "tenho saudade de um tempo que não volta"],
  objetivos: ["quero abrir meu próprio negócio um dia", "estou juntando forças para mudar de área", "meu plano é terminar o que comecei este ano", "gostaria de aprender algo totalmente novo", "tenho uma ideia grande e não sei por onde começar"],
  politica: ["a discussão sobre o governo azedou a ceia", "não aguento mais notícia de político", "fico pensando em quem merece meu voto", "o imposto subiu e todo mundo reclamou", "na mesa do bar só se falava de eleição"],
  religiao: ["acendi uma vela e agradeci pelo dia", "minha fé me segura nos dias ruins", "fui ao culto com a família no domingo", "tenho rezado mais ultimamente", "estou me reaproximando da espiritualidade"],
  filosofia: ["às vezes me pergunto pra que tudo isso", "o tempo anda passando rápido demais", "será que a gente escolhe ou é escolhido pelo destino", "penso muito no que realmente importa", "fico refletindo sobre ser feliz de verdade"],
  estudo: ["a matéria de hoje foi puxada demais", "preciso revisar tudo antes da avaliação", "o professor explicou e eu não entendi nada", "passei a noite estudando para o exame", "minha nota saiu e fiquei surpreso"],
  trabalho: ["o gerente marcou uma conversa comigo amanhã", "meu colega levou o crédito do meu projeto", "recebi uma proposta de outra empresa", "o expediente hoje não terminou nunca", "estou preparando uma apresentação para a diretoria"],
  namoro: ["a gente discutiu por causa de uma bobagem", "recebi uma mensagem dele depois de dias", "estou conhecendo alguém e tô animado", "ela me pediu um tempo na relação", "combinei um jantar a dois no sábado"],
  familia: ["minha avó contou histórias do tempo dela", "meu irmão brigou com meu pai de novo", "a família toda se reuniu em casa", "minha filha me abraçou do nada hoje", "estou ajudando minha mãe com as consultas"],
  amizade: ["encontrei um amigo de infância na rua", "meus amigos marcaram um churrasco", "briguei feio com minha melhor amiga", "uma amiga me ligou só para saber de mim", "o grupo da turma está parado há semanas"],
  saude: ["acordei com a garganta arranhando", "preciso marcar um exame de rotina", "meu joelho está doendo ao subir escada", "o médico mudou meu remédio", "estou me recuperando de uma virose"],
  sono: ["rolei na cama até as quatro da manhã", "acordei três vezes durante a noite", "tive um sonho muito esquisito essa noite", "hoje a vontade é de capotar logo cedo", "tô dormindo mal faz uma semana"],
  dinheiro: ["o cartão virou em um valor que me assustou", "preciso cortar gastos urgentemente", "o mercado ficou caríssimo este mês", "estou guardando um pouco todo mês", "a conta de luz veio absurda"],
  comida: ["feito um bolo de laranja e ficou ótimo", "tô morrendo de vontade de comer lasanha", "pedimos comida japonesa ontem à noite", "me deu uma fome fora de hora", "cozinhei pela primeira vez para a família"],
  esporte: ["meu time virou o jogo nos acréscimos", "voltei a treinar depois de meses parado", "fui correr no parque ao amanhecer", "a final do campeonato foi emocionante", "levei meu filho para a aula de natação"],
  musica: ["descobri uma banda nova que adorei", "fiquei repetindo a mesma canção o dia inteiro", "vou a um festival no mês que vem", "peguei o violão depois de anos", "a trilha daquele show ficou na minha cabeça"],
  filmes: ["terminei uma série que me prendeu demais", "o final do filme me deixou sem palavras", "fui ao cinema sozinho e gostei", "comecei um anime recomendado por um amigo", "o episódio de ontem foi uma loucura"],
  jogos: ["passei a tarde numa partida de xadrez", "zerei um jogo que me acompanhava há meses", "meu console deu problema no pior momento", "jogamos truco até tarde", "perdi a partida por um detalhe bobo"],
  viagem: ["estamos planejando uma viagem para o litoral", "o voo atrasou e perdemos a conexão", "fiquei num hotel pequeno e aconchegante", "conheci uma cidade linda na estrada", "queria muito fazer um mochilão"],
  pets: ["meu cachorro me recebeu pulando de alegria", "a gata dormiu no meu colo a tarde toda", "levei o bichinho ao veterinário hoje", "o filhote destruiu meu chinelo", "tô pensando em adotar um animalzinho"],
  casa: ["decidi reorganizar a sala inteira", "o vizinho de cima faz barulho de madrugada", "a obra no apartamento não acaba", "passei o dia limpando a casa toda", "troquei os móveis do quarto"],
  compras: ["encontrei uma liquidação ótima", "o pedido chegou com defeito", "fui ao shopping só para olhar e acabei comprando", "estou procurando um presente para minha mãe", "a entrega prometida não apareceu"],
  transporte: ["o ônibus demorou quarenta minutos", "fiquei preso no trânsito por horas", "meu carro foi para a oficina", "vim de bicicleta hoje e foi ótimo", "o aplicativo cancelou minha corrida duas vezes"],
  festa: ["estou organizando a festinha de aniversário", "vou a um casamento no fim do mês", "a formatura do meu sobrinho é amanhã", "preparamos a ceia de natal com antecedência", "a balada de ontem foi longa"],
  hobbies: ["comecei a ler um romance antigo", "passei a tarde pintando", "minha horta deu os primeiros tomates", "estou aprendendo a fazer crochê", "escrevi um poema de madrugada"],
  aparencia: ["cortei o cabelo bem curtinho", "fiz uma tatuagem pequena no braço", "me olhei no espelho e não me reconheci", "resolvi mudar o visual", "tô tentando emagrecer sem sofrimento"],
  tecnologia: ["meu celular travou de novo", "o programa que escrevi finalmente rodou", "a internet some toda hora aqui", "instalei uma atualização e quebrou tudo", "comprei um teclado novo e adorei"],
  idiomas: ["estou praticando conversação em inglês", "tentei falar espanhol com um turista", "decorei vinte palavras novas hoje", "não consigo pegar o sotaque francês", "faço uma aula online toda noite"],
  clima: ["o céu ficou cinza de repente", "tá um calorão que não deixa ninguém pensar", "choveu a tarde inteira por aqui", "o vento derrubou umas folhas no quintal", "amanheceu um friozinho gostoso"],
  rotina: ["acordo sempre no mesmo horário", "domingo à noite me bate uma moleza", "o fim de semana foi só de descanso", "tô tentando criar uma rotina melhor", "sexta-feira chegou e eu nem vi"],
  ciencia: ["li que descobriram um planeta novo", "fico fascinado com a vida no fundo do mar", "vi um documentário sobre o universo", "gosto de entender como as coisas funcionam", "assisti a uma chuva de meteoros"],
};

/** Conversa sem assunto definido: a Iris aprende a reconhecer o "geral". */
export const GENERAL_SENTENCES = [
  "hoje foi um dia normal", "não aconteceu nada de mais", "só passei para conversar", "estou aqui pensando em umas coisas",
  "acabei de chegar", "tô de boa", "nada demais por aqui", "fiz umas coisinhas hoje", "estou meio disperso", "acordei diferente hoje",
  "aconteceu uma coisa engraçada", "tive uma ideia agora", "mudei de ideia sobre uma coisa", "estou curioso com umas coisas",
  "queria te contar uma coisa", "hoje o dia passou voando", "tô sem assunto mas queria falar", "hoje me peguei pensando bobagem",
  "tive uma conversa interessante", "resolvi umas pendências", "o dia hoje foi comprido", "me aconteceu algo inesperado",
];

/** Exemplos de humor. */
export const MOOD_SENTENCES: Record<"pos" | "neg" | "neu", string[]> = {
  pos: [
    "estou muito feliz hoje", "deu tudo certo", "adorei o resultado", "que alegria", "fiquei orgulhoso", "foi uma tarde ótima",
    "tô radiante", "consegui o que queria", "me senti leve", "o dia foi maravilhoso", "tô animado", "que alívio, passou",
    "gostei muito", "foi perfeito", "ganhei um presente", "fiquei empolgado", "tudo tranquilo e bom", "me diverti bastante",
    "estou satisfeito", "recebi uma boa notícia", "foi incrível", "estou realizado", "que dia lindo", "tô muito contente",
    "valeu cada minuto", "saiu melhor do que eu esperava", "estou com o coração tranquilo", "foi uma delícia",
  ],
  neg: [
    "estou muito triste", "tudo deu errado", "odiei o resultado", "que tristeza", "fiquei decepcionado", "foi um dia péssimo",
    "tô arrasado", "perdi o que tinha conquistado", "me senti vazio", "o dia foi horrível", "tô desanimado", "que raiva",
    "não gostei nada", "foi um desastre", "levei uma bronca", "fiquei com medo", "tudo difícil e pesado", "sofri bastante",
    "estou exausto", "recebi uma má notícia", "foi frustrante", "estou muito mal", "que dia ruim", "tô com o coração apertado",
    "não aguento mais isso", "saiu pior do que eu temia", "estou sem esperança", "foi uma tristeza só",
  ],
  neu: [
    "fui ao mercado", "vou sair mais tarde", "estou em casa", "tenho uma reunião às três", "li uma matéria", "chegou uma encomenda",
    "a rua está movimentada", "tomei um café", "preciso responder uma mensagem", "amanhã é terça", "troquei de lugar na sala",
    "vi um vizinho passando", "o relógio parou", "organizei uns papéis", "fiz uma ligação rápida", "passei pela padaria",
    "abri a janela agora", "o dia está passando", "anotei uma coisa", "estou olhando o celular", "mudei o horário do alarme",
    "separei umas roupas", "sentei um pouco", "vou caminhar até ali", "lavei a louça", "esperei o ônibus", "estou lendo um aviso",
  ],
};

/** Reações e perguntas genéricas (servem a qualquer assunto): o modelo aprende o estilo da Iris com elas. */
export const GENERIC_REACTIONS: Record<"pos" | "neg" | "neu", string[]> = {
  pos: [
    "Que bom ouvir isso, {c}.", "Fico contente por você, {c}.", "Isso me alegra, {c}.", "Boa notícia, {c}.", "Gosto de saber disso, {c}.",
    "Que coisa boa, {c}.", "Dá gosto de ouvir, {c}.", "Isso merece um sorriso, {c}.", "Que alívio, {c}.", "Bonito isso, {c}.",
    "Fico feliz em saber, {c}.", "Que ótimo, {c}. Você merece.",
  ],
  neg: [
    "Sinto muito, {c}.", "Isso deve ter sido difícil, {c}.", "Entendo que isso pese, {c}.", "Que situação chata, {c}.",
    "Obrigada por me contar, {c}.", "Dá para sentir o peso disso, {c}.", "Poxa, {c}. Sinto por isso.", "Isso cansa mesmo, {c}.",
    "Estou com você nessa, {c}.", "Que pena, {c}. Passa por aqui comigo.", "Respira um pouco, {c}. Estou aqui.", "Entendo, {c}. Vamos com calma.",
  ],
  neu: [
    "Entendi, {c}.", "Certo, {c}.", "Interessante, {c}.", "Faz sentido, {c}.", "Estou ouvindo, {c}.", "Hum, entendi, {c}.",
    "Anotei aqui, {c}.", "Continua, {c}.", "Saquei, {c}.", "Tá bom, {c}. Estou por aqui.", "Compreendo, {c}.", "Ok, {c}. Me conta mais.",
  ],
};

export const GENERIC_QUESTIONS = {
  /** servem para qualquer humor */
  ask: ["Quer me contar mais?", "Como foi para você?", "O que você sentiu?", "Como você se sente em relação a isso?"],
  /** quando a pessoa está mal ou só contando algo */
  askHard: [
    "O que aconteceu?", "Como você está com isso?", "Desde quando isso é assim?", "E agora, o que você pensa em fazer?",
    "O que você gostaria que acontecesse?", "Isso começou hoje?",
  ],
  /** quando a pessoa está bem */
  askGood: ["O que mais te deixou feliz nisso?", "Como você se sentiu?", "Quem mais ficou sabendo?", "O que veio de bom depois disso?"],
  deep: [
    "O que isso significa para você?", "O que ajudaria agora?", "Tem alguém com quem você possa dividir isso?", "O que você faria diferente?",
    "O que pesa mais nisso tudo?", "Se pudesse mudar uma coisa, qual seria?", "O que você espera que aconteça depois?", "Qual é a parte mais difícil disso?",
  ],
  close: [
    "Eu continuo aqui, sem pressa.", "Se quiser mudar de assunto, é só dizer.", "Foi bom conversar sobre isso com você.",
    "A gente pode seguir por onde você quiser.", "Quando quiser retomar, eu estou por aqui.", "Fico feliz de ouvir você.",
  ],
};

/** Perguntas que retomam o que a pessoa disse. {np} = "a prova", {em_np} = "na prova". */
export const NP_QUESTIONS: Record<"ask" | "deep", string[]> = {
  ask: ["Me conta mais sobre {np}.", "Quer falar mais sobre {np}?", "O que mais te marcou {em_np}?", "E {np}, como ficou?"],
  deep: ["O que você pensa sobre {np}?", "O que mudaria {em_np} se você pudesse?", "O que {np} significa para você?", "Me conta o que mais pesa {em_np}."],
};

/** Mais palavras por assunto (segunda leva de treino). */
export const TOPIC_WORDS_EXTRA: Record<string, string> = {
  ansiedade: "taquicardia respiração ofegante insegurança medo tremor inquietação apreensão alerta colapso nervoso",
  emocoes: "tristeza desabafo lágrimas desespero chateação mágoa fracasso inútil desesperança irritação raiva",
  solidao: "solitário desamparado afastado distante esquecido invisível silêncio sem companhia",
  correria: "prazo atrasado urgente pendências sobrecarregado ocupado apressado tarefas sem folga corrido",
  saudade: "saudoso fotografias álbum cidade natal escola antiga memórias revivendo época passou",
  objetivos: "vontade desejo ideia empreender negócio conquistar realizar sonhar crescer promoção futuro",
  politica: "candidato debate reforma ministro prefeito urna voto partidos protesto notícias",
  religiao: "deus pastor padre rezar culto santo agradeci benção graças orações reza",
  filosofia: "propósito reflexão vida morte pensar existir sentido acaso ética finitude",
  estudo: "avaliação cálculo exercícios disciplina semestre professor reprovado aprovado bolsa monografia leitura",
  trabalho: "gerente diretoria prazo proposta salário contratação demissão equipe e-mail chefa promoção",
  namoro: "beijo encontro apaixonado término tempo na relação traição pedido ciumento paquera amor",
  familia: "sogra neto cunhado parentes reunião visita aniversário avós padrasto mãe pai",
  amizade: "melhor amigo convite churrasco turma grupo brigamos reencontro afastamento confiança parceria",
  saude: "vacina sangue pressão sintomas virose garganta dor de cabeça enjoo tratamento fisioterapia",
  sono: "insônia cochilo capotar cama travesseiro acordei sonolento pesadelo dormi madrugada despertador",
  dinheiro: "conta quitei empréstimo juros parcela mercado caro barato poupar financiar contracheque",
  comida: "macarrão lanche sorvete pão feijão arroz hambúrguer bolo cozinhei jantei padaria",
  esporte: "rebaixado pedalar gol torcida estádio derrota vitória atleta partida academia bola",
  musica: "ingresso canção letra refrão ouvindo banda guitarra instrumento cantei coral melodia",
  filmes: "terror comédia drama estreou trailer episódio personagem final roteiro sessão",
  jogos: "fase partida zerei console dominó baralho tabuleiro derrota vitória online",
  viagem: "reservei hotel serra mala feriado voo litoral estrada turista excursão bagagem",
  pets: "patinha gatinha ração veterinário vacina filhote latido miado passeio adotei",
  casa: "pintar parede sala quarto cozinha banheiro obra aluguel apartamento faxina",
  compras: "sapato roupa tamanho troca cupom frete oferta carrinho mercado estoque",
  transporte: "engarrafamento carteira motorista pneu oficina passagem trânsito atrasou ônibus lotado",
  festa: "surpresa convidados bolo presente decoração ceia brinde comemoramos música balões",
  hobbies: "romance ficção lápis cerâmica pintei costura jardinagem tricô bordado instrumento",
  aparencia: "pintei salão unhas quilos engordei emagreci barba maquiagem estilo penteado",
  tecnologia: "notebook liga aplicativo python código atualização senha conta bateria servidor",
  idiomas: "pronúncia vocabulário italiano conjugação aula intercâmbio legenda conversação fluente",
  clima: "dilúvio friaca calorão tempestade neblina trovão sol relâmpago úmido abafado",
  rotina: "segunda-feira domingo sofá sexta hábito horário cumprindo agenda semana descanso",
  ciencia: "buracos negros telescópio fósseis átomos experimento evolução gravidade cometa teoria",
};

/** Mais frases por assunto. */
export const TOPIC_SENTENCES_EXTRA: Record<string, string[]> = {
  ansiedade: ["sinto o coração disparando sem motivo nenhum", "fico revirando os problemas na cabeça a noite toda"],
  emocoes: ["tô com um aperto no peito e nem sei por quê", "hoje tudo me irrita e me cansa"],
  solidao: ["moro numa cidade nova e não conheço ninguém", "o telefone não toca faz tempo"],
  correria: ["não consegui nem tomar um café sentado hoje", "meus dias viraram uma maratona de tarefas"],
  saudade: ["fiquei vendo vídeos antigos da família", "tenho falta de gente que já não está por perto"],
  objetivos: ["pretendo fazer uma pós-graduação em breve", "um dia quero ter uma casa só minha"],
  politica: ["os vereadores aprovaram uma lei polêmica", "discuti com meu primo sobre quem governa melhor"],
  religiao: ["participei de uma celebração linda ontem", "conversei com o padre da paróquia"],
  filosofia: ["fico pensando se a gente tem controle sobre as coisas", "me pergunto o que deixamos para o mundo"],
  estudo: ["o seminário de amanhã me deixou tenso", "tô ralando para fechar o semestre com média boa"],
  trabalho: ["a diretoria vai anunciar mudanças amanhã", "meu supervisor me elogiou na frente de todos"],
  namoro: ["ele me chamou para conhecer a família dele", "a gente se deu um beijo no fim do encontro"],
  familia: ["o aniversário da vovó reuniu todo mundo", "meu pai está ficando cada vez mais esquecido"],
  amizade: ["combinei um café com uma amiga antiga", "meus amigos me fizeram uma surpresa linda"],
  saude: ["estou com uma tosse que não passa há dias", "fui buscar o resultado do check-up"],
  sono: ["só consigo pegar no sono depois da meia-noite", "acordei com a cabeça pesada e sem descanso"],
  dinheiro: ["o salário mal cobre as despesas fixas", "paguei a última parcela do financiamento"],
  comida: ["preparei uma sopa quentinha para o jantar", "provei um doce novo na confeitaria"],
  esporte: ["o atacante marcou um golaço no final", "completei minha primeira corrida de dez quilômetros"],
  musica: ["fui a um concerto de música clássica", "montei uma lista de músicas para o treino"],
  filmes: ["revi um clássico do cinema com a família", "comecei uma série policial que prende muito"],
  jogos: ["ganhei de lavada num jogo de cartas", "instalei um jogo novo e viciei"],
  viagem: ["fechei o pacote de viagem para o fim do ano", "perdi a hora e quase não peguei o avião"],
  pets: ["meu coelho comeu o fio do carregador", "levei a cachorrinha para tomar vacina"],
  casa: ["troquei as cortinas da sala e ficou lindo", "o encanador veio consertar o vazamento"],
  compras: ["troquei a camisa que ficou grande", "achei um cupom e usei na hora"],
  transporte: ["a van atrasou e perdi o compromisso", "levei o carro para revisão"],
  festa: ["a decoração da festa ficou bonita", "o brinde de ano novo foi emocionante"],
  hobbies: ["terminei de montar um quebra-cabeça enorme", "aprendi um ponto novo de bordado"],
  aparencia: ["mudei o penteado e recebi muitos elogios", "resolvi cuidar mais da pele"],
  tecnologia: ["o sistema reiniciou sozinho no meio do trabalho", "troquei a senha de todas as contas"],
  idiomas: ["consegui entender uma música inteira em inglês", "fiz uma prova de proficiência de espanhol"],
  clima: ["a neblina cobriu a cidade de manhã", "caiu um temporal forte no fim da tarde"],
  rotina: ["segunda começa tudo de novo", "tô mantendo o mesmo horário de acordar"],
  ciencia: ["li uma matéria sobre exploração espacial", "fiquei curioso sobre como surgiram os fósseis"],
};

/** Mais exemplos de humor, de situações do dia a dia (segunda leva). */
export const MOOD_SENTENCES_EXTRA: Record<"pos" | "neg" | "neu", string[]> = {
  pos: [
    "conheci uma pessoa muito simpática hoje", "meu filho foi bem na escola", "recebi um aumento", "fui elogiado pelo meu trabalho",
    "meu time venceu o clássico", "fui aprovado no processo", "o dia amanheceu lindo", "reencontrei amigos queridos",
    "fizemos as pazes e foi um alívio", "o bolo ficou uma delícia", "a viagem foi ótima", "ganhei um abraço apertado",
    "me convidaram para um passeio legal", "terminei o curso com louvor", "me senti em paz hoje", "comprei exatamente o que queria",
    "o plano deu certo", "o médico disse que está tudo bem", "tive uma tarde muito agradável", "que sensação gostosa",
    "me chamaram para uma entrevista", "recebi uma mensagem carinhosa", "amanhecei disposto", "o jantar foi perfeito",
  ],
  neg: [
    "meu time foi eliminado", "a internet caiu de novo e atrapalhou tudo", "o ônibus passou direto e me atrasei", "perdi meu documento",
    "discuti feio com meu amigo", "levei um fora", "fiquei o dia todo sem sinal", "o filme foi uma chatice", "a prova foi difícil demais",
    "hoje chorei bastante", "tô sem paciência para nada", "me sinto perdido", "ninguém me respondeu", "me trataram mal na loja",
    "estragaram o meu dia", "a conta veio altíssima", "meu cachorro adoeceu", "perdi o ônibus de novo", "fiquei doente de novo",
    "o chefe gritou comigo", "tô cheio de problemas", "ando muito aflito", "foi uma noite péssima", "tudo me irrita hoje",
  ],
  neu: [
    "fui ao médico de manhã", "tive um sonho esquisito", "vou cozinhar macarrão", "comprei um tênis", "o vizinho deu uma festa",
    "li sobre dinossauros", "troquei de celular", "estou vendo um jogo", "acordei cedo hoje", "vou para a praia no sábado",
    "o ônibus chega às sete", "vou ao mercado depois", "passei o dia em casa", "fiz uma tatuagem pequena", "encontrei um conhecido na rua",
    "choveu à tarde", "preciso arrumar meu quarto", "estou com uma ideia", "vou dormir mais tarde hoje", "tenho um compromisso amanhã",
    "o jogo começa às oito", "minha mãe ligou", "conheci um lugar novo", "hoje é quinta",
  ],
};
