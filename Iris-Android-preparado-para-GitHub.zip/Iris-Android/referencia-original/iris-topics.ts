import { norm } from "./iris-local.ts";
import { compose, lmMood, lmTopic } from "./iris-lm.ts";

/**
 * Conversa da Iris: assuntos do dia a dia, reações que mudam conforme o humor
 * da frase, perguntas que aprofundam o papo, curiosidades, charadas e jogos.
 * Tudo local, próprio, sem modelo externo: funciona sem internet. Textos de entrada já vêm normalizados (norm).
 */

type Line = { role: string; content: string };
export type Mood = "pos" | "neg" | "neu";

export type Topic = {
  id: string;
  test: RegExp;
  pos: string[];
  neg: string[];
  neu: string[];
  ask: string[];
  deep: string[];
  close: string[];
};

function T(
  id: string,
  test: RegExp,
  pos: string[],
  neg: string[],
  neu: string[],
  ask: string[],
  deep: string[],
  close: string[],
): Topic {
  return { id, test, pos, neg, neu, ask, deep, close };
}

// ---------------------------------------------------------------- humor

const POS =
  /\b(bom|boa|otim[oa]|legal|maravilh\w*|feliz|animad[oa]|adorei|amei|gostei|incrivel|show|top|consegui|passei|ganhei|deu certo|tranquil[oa]|de boa|curti|perfeit[oa]|divertid[oa]|aprovad[oa]|promovid[oa]|alivi\w*|orgulh\w*|empolgad[oa]|lindo|linda|massa|sensacional|elogi\w*|parabens|conquist\w*|venci|ganhou|surpresa boa)\b/;
const NEG =
  /\b(mal|pessim[oa]|horrivel|ruim|triste|chat[oa]|cansad[oa]|estress\w*|odiei|detestei|perdi|reprovad[oa]|demitid[oa]|briguei|doente|problema|ansios[oa]|sozinh[oa]|pior|nao deu certo|deu errado|pesad[oa]|dificil|complicad[oa]|decepcion\w*|frustrad[oa]|desanimad[oa]|irritad[oa]|com raiva|sofr\w*|dor|dores|atrasad[oa]|pesadelo|saudade)\b/;

export function moodOf(n: string): Mood {
  const pos = POS.test(n.replace(/\bmelhor (amig[oa]s?|parceir[oa])\b/g, " "));
  const neg = NEG.test(n);
  const denied = /\bnao (foi|e|esta|ta|estou|to|gostei|curti|consegui|deu|tive|achei)\b/.test(n);
  if (pos && denied) return "neg";
  if (neg && !pos) return "neg";
  if (pos && !neg) return "pos";
  if (pos && neg) return /\b(mas|porem|so que)\b/.test(n) ? "neg" : "neu";
  return "neu";
}

// ---------------------------------------------------------------- assuntos

export const TOPICS: Topic[] = [
  T("ansiedade",
    /\b(ansiedade|ansios[oa]|estress\w*|sobrecarregad[oa]|esgotad[oa]|burnout|nervos[oa]|panico|tens[oa]|preocupad[oa]|preocupacao|aflit[oa]|agonia|pressao)\b/,
    ["Fico feliz que a cabeça esteja mais leve, {c}.", "Respirar fundo parece ter ajudado."],
    ["Isso pesa mesmo, {c}. Obrigada por me contar.", "Tanta coisa junta cansa qualquer um, {c}."],
    ["Entendi, {c}. Vamos com calma.", "Estou aqui, {c}. Sem pressa."],
    ["O que está mais apertado agora?", "Isso começou hoje ou já vem de uns dias?", "Se pudesse tirar uma coisa dos ombros agora, qual seria?"],
    ["Tem alguma coisa pequena que costuma te acalmar?", "Dá para dividir isso em partes menores? Qual é a primeira?", "Quando foi a última vez que você parou só para respirar?"],
    ["Se continuar pesando, vale conversar com alguém de confiança ou um profissional. Eu continuo aqui."]),
  T("emocoes",
    /\b(chorei|chorando|vontade de chorar|sem paciencia|perdid[oa] na vida|perdid[oa] na vida|sem rumo|sem animo|nao to a fim de nada|nao estou a fim de nada|sem vontade de nada|sem vontade|desmotivad[oa]|apatic[oa]|sem energia|decepcionad[oa]|culpa|culpad[oa]|vergonha|inseguranca|inseguro|insegura|autoestima|me sinto (?:mal|pessim[oa]|vazi[oa]))\b/,
    ["Que bom ouvir isso, {c}.", "Gosto de ouvir isso, {c}."],
    ["Sinto muito, {c}. Dias assim acontecem.", "Obrigada por contar, {c}. Isso importa."],
    ["Entendi, {c}. Estou aqui.", "Obrigada por dividir, {c}."],
    ["O que aconteceu hoje?", "O que mais pesa agora?", "Se quiser, me conta do começo."],
    ["O que ajudaria agora, mesmo que um pouquinho?", "Tem alguém com quem você gostaria de falar sobre isso?", "O que costuma te dar um respiro?"],
    ["Se isso continuar por muitos dias, vale conversar com alguém de confiança ou um profissional. Eu continuo aqui."]),
  T("solidao",
    /\b(sozinh[oa]|solidao|ninguem (me|liga|fala|conversa)|isolad[oa]|abandonad[oa]|sem ninguem|nao tenho amigos|me sinto so|vazio)\b/,
    ["Que bom que hoje o clima é outro, {c}.", "Gosto de ouvir isso."],
    ["Sinto muito, {c}. Solidão dói de um jeito silencioso.", "Obrigada por dizer isso em voz alta, {c}."],
    ["Entendi, {c}. Eu fico aqui com você.", "Estou por perto, {c}."],
    ["Faz tempo que você se sente assim?", "Tem alguém com quem você gostaria de falar mais?", "O que costuma deixar o dia menos solitário?"],
    ["Que tal mandar uma mensagem curta para alguém de quem você gosta?", "O que você fazia antes que te deixava mais perto das pessoas?", "Eu continuo aqui. O que mais está na sua cabeça?"],
    ["Conversar com gente de carne e osso também faz bem. Eu sigo aqui, mas não substituo isso."]),
  T("correria",
    /\b(correria|(?:vida|dia|semana|rotina|manha|tarde|mes|ano)s? (?:anda |esta |ta |foi |ficou |tava )?(?:muito |bem |super |tao )?(?:corrid[oa]|agitad[oa]|puxad[oa])|sem tempo|dia cheio|tempo livre|tempo pra mim|tempo para mim|preciso de um tempo|sem folego|so trabalho|nao paro)\b/,
    ["Que bom que deu conta, {c}.", "Dia cheio e bem vivido, {c}."],
    ["Correria assim esgota, {c}.", "Sem tempo nem para respirar, {c}. Isso cansa."],
    ["Vida corrida, {c}.", "Entendi, {c}."],
    ["O que está tomando mais o seu tempo?", "Tem alguma coisa que dá para tirar da lista?", "Quando foi a última vez que sobrou tempo só para você?"],
    ["Qual compromisso você adiaria se pudesse?", "Que pedacinho do dia seria só seu?", "O que te faz bem e ficou de fora da rotina?"],
    ["Posso armar um cronômetro de cinco minutos de pausa para você. Quer?"]),
  T("saudade",
    /\b(saudades?|lembrei de|lembranca|lembrancas|infancia|antigamente|na minha epoca|velhos tempos|nostalgia|recordar|recordacao)\b/,
    ["Que lembrança boa, {c}.", "Dá para sentir o carinho nisso."],
    ["Saudade aperta, {c}.", "Lembrar às vezes dói, {c}."],
    ["Memória boa se guarda, {c}.", "Isso diz muito sobre você."],
    ["Do que você mais sente falta?", "Quem estava com você nessa lembrança?", "Se pudesse voltar um dia a esse tempo, o que faria?"],
    ["O que dessa época ainda vive em você hoje?", "Tem algo que você queira reviver de algum jeito?", "Se pudesse falar com quem estava lá, o que diria?"],
    ["Lembranças assim valem ser contadas. Se quiser, anoto uma delas para você."]),
  T("objetivos",
    /\b(meu sonho|meta|metas|objetivo|objetivos|futuro|planos|plano|projeto de vida|carreira|quero ser|quero conseguir|quero aprender|ambicao|crescer na vida|realizar|sonhos)\b/,
    ["Que bom ter direção, {c}.", "Gosto de gente com plano, {c}."],
    ["Quando o futuro assusta, o primeiro passo parece longe, {c}.", "Entendi, {c}. Incerteza cansa."],
    ["Planos dão rumo, {c}.", "Entendi, {c}."],
    ["O que falta para dar o primeiro passo?", "Em quanto tempo você quer chegar lá?", "O que te move nesse objetivo?"],
    ["Qual é o menor passo que você pode dar hoje?", "Quem poderia te ajudar nisso?", "O que acontece se você não tentar?"],
    ["Posso anotar o objetivo e o primeiro passo para você. É só dizer anota."]),
  T("politica",
    /\b(politica|politico|eleicao|eleicoes|votar|governo|partido|esquerda|direita|deputado|senador|corrupcao|congresso|ministro)\b/,
    ["Entendi, {c}. Sua opinião é sua.", "Respeito o seu ponto de vista, {c}."],
    ["Política cansa, {c}. Dá para sentir.", "Entendi, {c}. Esse assunto mexe com todo mundo."],
    ["Política é um assunto delicado, {c}. Não tomo lado.", "Entendi, {c}. Não tomo lado, mas escuto."],
    ["O que te preocupa mais nisso?", "Isso afeta o seu dia a dia?", "O que você acha que poderia melhorar?"],
    ["Quais são os fatos que você tem em mãos?", "Como você escolhe a fonte das suas informações?", "Prefere falar de outra coisa por enquanto?"],
    ["Se quiser fatos, pesquiso fontes neutras. Opinião eu deixo para você."]),
  T("religiao",
    /\b(deus|igreja|rezar|oracao|fe|religiao|missa|culto|templo|biblia|espiritual|espiritualidade|umbanda|candomble|budismo|kardec|espirita|catolic[oa]|evangelic[oa]|ateu|ateia|rezei)\b/,
    ["Que bonito, {c}. Cada um tem a sua fé.", "Respeito muito isso, {c}."],
    ["Entendi, {c}. Fé e dúvida costumam andar juntas.", "Sinto muito, {c}. Isso pode ser pesado."],
    ["Respeito a sua fé, {c}.", "Entendi, {c}."],
    ["O que isso significa para você?", "Isso te acompanha desde a infância?", "O que a sua fé te dá nos dias difíceis?"],
    ["O que a prática te traz de paz?", "Tem alguma tradição que você mais preza?", "Você costuma conversar sobre isso com alguém?"],
    ["Não opino sobre crença, {c}, mas escuto com respeito."]),
  T("filosofia",
    /\b(sentido da vida|felicidade|ser feliz|destino|tempo passa|vida e curta|universo|deus existe|proposito|existencia|mudar de vida|envelhecer|velhice|valores|etica|liberdade|para que serve a vida)\b/,
    ["Pergunta profunda, {c}. Gosto dessas.", "Bonito pensar assim, {c}."],
    ["Pergunta grande, {c}. Pesa quando a gente se pergunta isso.", "Entendi, {c}. Esses pensamentos aparecem."],
    ["Pergunta grande merece calma, {c}.", "Entendi, {c}."],
    ["O que te levou a pensar nisso hoje?", "O que você acha?", "O que seria uma vida boa para você?"],
    ["O que dá sentido ao seu dia a dia?", "Quem te inspirou a pensar assim?", "O que mudaria se você pensasse diferente?"],
    ["Pensar nisso é humano. Se pesar demais, converse com alguém de confiança."]),
  T("estudo",
    /\b(prova|faculdade|escola|estudar|estudo|estudando|estudei|aula|aulas|professor|professora|enem|vestibular|concurso|tcc|curso|universidade|nota|notas|reprov\w*|aprovad[oa]|materia|dever de casa|tarefa|trabalho da escola|trabalho da faculdade|colegio|mestrado|doutorado|monografia)\b/,
    ["Que ótimo, {c}. Esforço aparece.", "Isso merece comemoração."],
    ["Dia de estudo pesado cansa, {c}.", "Nem sempre a nota mostra o esforço, {c}."],
    ["Estudo é maratona, {c}.", "Entendi, {c}."],
    ["Qual matéria está te dando mais trabalho?", "Para quando é isso?", "Você estuda melhor de manhã ou à noite?"],
    ["Já tentou estudar em blocos curtos com pausa no meio?", "O que ajuda você a fixar o conteúdo?", "O que você quer fazer com esse estudo lá na frente?"],
    ["Se quiser, armo um cronômetro de foco para você estudar. É só dizer quantos minutos."]),
  T("trabalho",
    /\b(trabalho|servico|chefe|emprego|empresa|reuniao|colega de trabalho|expediente|demissao|demitid[oa]|entrevista|curriculo|freela|home office|escritorio|cliente|projeto|turno|plantao|hora extra)\b/,
    ["Que bom, {c}. Reconhecimento faz diferença.", "Trabalho andando bem ajuda o resto a respirar."],
    ["Trabalho pesado esgota, {c}.", "Isso é desgastante, {c}. Faz sentido você estar assim."],
    ["Trabalho ocupa um bom pedaço do dia, {c}.", "Entendi, {c}."],
    ["O que mais ocupou você hoje?", "É o ritmo, as pessoas ou o tipo de tarefa que pesa mais?", "Você gosta do que faz?"],
    ["O que você mudaria nesse trabalho se pudesse?", "Você consegue separar um tempo seu depois do expediente?", "Isso te dá orgulho ou só cansaço?"],
    ["Quando o trabalho invade o dia todo, uma pausa curta ajuda. Quer um cronômetro de cinco minutos?"]),
  T("namoro",
    /\b(namorad[oa]|namoro|crush|paquera|ficante|casamento|casar|terminei|terminamos|terminar|encontro|date|relacionamento|apaixonad[oa]|paixao|ciume|ciumes|traicao|traiu|ex)\b/,
    ["Que bom ver você assim, {c}.", "Amor bom faz o dia render."],
    ["Coração apertado é difícil, {c}.", "Sinto muito, {c}. Relação mexe com tudo."],
    ["Coisa de coração merece atenção, {c}.", "Entendi, {c}."],
    ["Como você está com isso?", "O que aconteceu?", "Como isso começou?"],
    ["O que você sente que precisa agora: conselho ou só ser ouvido?", "O que é mais importante para você numa relação?", "Já conversou com a outra pessoa sobre isso?"],
    ["Decisão de coração não precisa sair hoje. Dá um tempo para ela assentar."]),
  T("familia",
    /\b(familia|mae|pai|filho|filha|irmao|irma|avo|avos|vovo|vovos|tio|tia|primo|prima|sobrinh[oa]|marido|esposa|esposo|parentes|cunhad[oa]|sogr[oa]|neto|neta|padrasto|madrasta|genro|nora)\b/,
    ["Família boa é um presente, {c}.", "Que bom, {c}. Dá gosto de ouvir."],
    ["Família é difícil às vezes, {c}.", "Sinto muito, {c}. Coisa de casa pesa dobrado."],
    ["Gente da sua vida, {c}.", "Entendi, {c}."],
    ["Como estão as coisas em casa?", "Vocês se veem sempre?", "O que aconteceu?"],
    ["O que você mais admira nessa pessoa?", "Como você gostaria que isso fosse resolvido?", "Vocês costumam conversar sobre isso?"],
    ["Se fizer sentido, um recado carinhoso hoje pode render muito. Quer que eu anote um lembrete?"]),
  T("amizade",
    /\b(amigo|amiga|amigos|amigas|amizade|turma|galera|parceiro|parceira|colega|conheci (?:uma|um|alguem)|fiz um amigo|fiz uma amiga|apresentaram)\b/,
    ["Amizade boa vale ouro, {c}.", "Que bom ter gente assim."],
    ["Chato isso com amigo, {c}.", "Amizade também machuca às vezes, {c}."],
    ["Amigo é gente que escolhemos, {c}.", "Entendi, {c}."],
    ["Há quanto tempo vocês são amigos?", "O que vocês costumam fazer juntos?", "O que aconteceu?"],
    ["O que torna essa amizade especial?", "Você já falou com essa pessoa sobre isso?", "Quando foi a última vez que vocês se viram?"],
    ["Uma mensagem curta para esse amigo hoje já faz bem. Quer que eu anote para você lembrar?"]),
  T("saude",
    /\b(doente|doenca|gripe|resfriado|febre|dor de cabeca|dor nas costas|dor de barriga|dor no|dor na|medico|consulta|exame|exames|hospital|remedio|dentista|cirurgia|saude|machuquei|machucad[oa]|tosse|alergia|enxaqueca|diabetes|sintoma|sintomas|vacina|fisioterapia)\b/,
    ["Que bom que a saúde está colaborando, {c}.", "Boa notícia, {c}."],
    ["Sinto muito, {c}. Se o incômodo continuar ou piorar, vale procurar um médico.", "Saúde é prioridade, {c}. Descansa e, se piorar, procura atendimento."],
    ["Cuida disso, {c}. Eu não diagnostico, mas posso ouvir.", "Entendi, {c}."],
    ["Faz quanto tempo que está assim?", "Você já foi ao médico ou ainda não?", "Como você está se sentindo agora?"],
    ["Já anotou os sintomas para falar com o médico?", "Está conseguindo descansar?", "Posso armar um cronômetro para o seu remédio, se quiser."],
    ["Qualquer sinal forte ou que não passa, procure atendimento. Eu fico por aqui."]),
  T("sono",
    /\b(dormir|dormi|sono|insonia|acordei|acordar|sonhei|pesadelo|cochilo|madrugada|acordado|nao consigo dormir|dormindo|cama|sonho estranho|tive um sonho|sonhando)\b/,
    ["Dormir bem muda o dia inteiro, {c}.", "Que ótimo, {c}. Descanso de verdade é raro."],
    ["Noite ruim cobra o preço no dia, {c}.", "Sinto muito, {c}. Sono ruim bagunça tudo."],
    ["Sono é combustível, {c}.", "Entendi, {c}."],
    ["O que atrapalha seu sono?", "A que horas você costuma deitar?", "Dormiu bem essa noite?"],
    ["Telas antes de dormir pesam. Você costuma usá-las até tarde?", "Um horário fixo para deitar ajuda muito. Você tem?", "Prefere que eu arme um cronômetro de descanso?"],
    ["Se a insônia virar rotina, vale falar com um médico. Por hoje, desacelera as luzes."]),
  T("dinheiro",
    /\b(dinheiro|grana|divida|dividas|salario|conta de luz|boleto|fatura|cartao|investir|investimento|economizar|poupar|aluguel|financiamento|falido|quebrado|pagar|pagamento|imposto|dolar|bolso)\b/,
    ["Que alívio financeiro, {c}.", "Organizar as contas dá paz, {c}."],
    ["Aperto financeiro estressa, {c}.", "Conta apertada pesa, {c}. Passo a passo se resolve."],
    ["Dinheiro mexe com a cabeça, {c}.", "Entendi, {c}."],
    ["O que mais te preocupa nisso?", "É algo pontual ou do mês inteiro?", "Você já listou o que vence primeiro?"],
    ["Separar o essencial do que dá para adiar ajuda. Já fez isso?", "Qual gasto você mais gostaria de reduzir?", "Tem algum plano para os próximos meses?"],
    ["Posso anotar suas contas do mês para você não esquecer. É só dizer anota."]),
  T("comida",
    /\b(comida|fome|almoco|jantar|jantei|almocei|cafe da manha|cafe|pizza|hamburguer|lanche|restaurante|cozinhar|doce|chocolate|sorvete|churrasco|feijoada|massa|sobremesa|dieta|comi|comendo|janta|salgado|padaria|tempero|prato)\b/,
    ["Que delícia, {c}. Deu água na boca.", "Boa refeição melhora o dia, {c}."],
    ["Que pena que não foi bom, {c}.", "Fome atrapalha tudo, {c}."],
    ["Comida é assunto sério, {c}.", "Entendi, {c}."],
    ["Qual é o seu prato favorito?", "Você cozinha ou prefere comer fora?", "O que você está com vontade de comer?"],
    ["Qual comida te lembra a infância?", "Tem algum prato que você faz muito bem?", "Doce ou salgado, qual ganha?"],
    ["Se quiser uma receita, é só pedir que eu pesquiso."]),
  T("esporte",
    /\b(futebol|jogo do|time|campeonato|gol|torcida|flamengo|corinthians|palmeiras|vasco|gremio|cruzeiro|atletico|botafogo|treino|treinei|academia|musculacao|corrida|corri|corro|correr|correndo|nadar|natacao|basquete|volei|tenista|jiu jitsu|ciclismo|pedalar|maratona|esporte|fluminense|athletico|bahia|fortaleza)\b/,
    ["Que vitória, {c}. Dá para sentir a energia.", "Esporte alegra, {c}."],
    ["Que derrota dolorida, {c}.", "Time e treino cobram, {c}."],
    ["Esporte é emoção, {c}.", "Entendi, {c}."],
    ["Você torce ou pratica?", "Como foi o jogo?", "Há quanto tempo você treina ou acompanha?"],
    ["Qual foi o momento mais marcante?", "O que te prende nesse esporte?", "Tem um ídolo nele?"],
    ["Se quiser resultado ao vivo, é só pedir que eu pesquiso."]),
  T("musica",
    /\b(musica|musicas|cancao|cantor|cantora|banda|show|album|playlist|violao|guitarra|piano|cantar|cantei|ouvindo|rock|sertanejo|funk|samba|pagode|mpb|rap|forro|festival|batera|bateria|trilha sonora|refrao)\b/,
    ["Boa música muda o humor, {c}.", "Que beleza, {c}."],
    ["Às vezes música triste também faz companhia, {c}.", "Entendi, {c}."],
    ["Música é assunto bom, {c}.", "Entendi, {c}."],
    ["Qual estilo você mais ouve?", "O que está tocando por aí?", "Você toca ou canta alguma coisa?"],
    ["Qual música te marcou em algum momento da vida?", "Você prefere ouvir sozinho ou em grupo?", "Tem uma música que sempre melhora o seu dia?"],
    ["Eu não toco som aqui, mas fico feliz em ouvir o que você ouve."]),
  T("filmes",
    /\b(filme|filmes|serie|series|netflix|cinema|anime|novela|documentario|episodio|temporada|maratonar|assistir|assisti|assistindo|stand up|youtube|video|trailer)\b/,
    ["Boa pedida, {c}.", "Que bom, {c}. Tempo bem usado."],
    ["Que pena, {c}. Nem tudo vale o tempo.", "Entendi, {c}. Às vezes enrola demais."],
    ["Boa história faz companhia, {c}.", "Entendi, {c}."],
    ["Sem spoiler: de que se trata?", "O que prendeu você nele?", "Gosta mais de filme ou de série?"],
    ["Qual personagem mais te marcou?", "Você recomendaria?", "Qual é o último que realmente te surpreendeu?"],
    ["Se quiser, anoto o nome para você não esquecer. É só dizer anota."]),
  T("jogos",
    /\b(jogo|jogos|game|games|videogame|video game|playstation|xbox|nintendo|minecraft|fortnite|free fire|valorant|roblox|gamer|jogando|joguei|rpg|tabuleiro|xadrez|truco|baralho|dama|domino)\b/,
    ["Que boa, {c}. Vitória merece comemoração.", "Jogo bom faz o tempo voar, {c}."],
    ["Derrota irrita, {c}.", "Chato quando dá tilt, {c}."],
    ["Jogo é diversão séria, {c}.", "Entendi, {c}."],
    ["Qual jogo você mais joga?", "Joga sozinho ou com amigos?", "Que tipo de jogo você curte?"],
    ["Qual foi o jogo da sua vida?", "Você prefere desafio ou relaxar jogando?", "Tem alguma partida marcante?"],
    ["Se quiser brincar comigo, peça uma charada ou diga vamos brincar."]),
  T("viagem",
    /\b(viagem|viajar|viajei|ferias|passagem|aviao|aeroporto|hotel|praia|mochilao|turismo|passeio|passear|estrada|mala|feriado|resort|cruzeiro|acampar|camping|trilha|viajo|viajando)\b/,
    ["Que delícia, {c}. Viagem faz bem à cabeça.", "Boa, {c}. Aproveita cada pedaço."],
    ["Que chato, {c}. Viagem com perrengue cansa.", "Entendi, {c}. Nem todo passeio sai como a gente quer."],
    ["Viagem muda o olhar, {c}.", "Entendi, {c}."],
    ["Para onde você vai ou foi?", "Foi planejado ou de última hora?", "Você prefere praia, montanha ou cidade?"],
    ["Qual foi o lugar mais bonito que você já viu?", "Prefere viajar sozinho ou acompanhado?", "Qual seria o próximo destino dos sonhos?"],
    ["Quando decidir o destino, posso pesquisar para você."]),
  T("pets",
    /\b(cachorro|cachorra|cao|gato|gata|pet|bicho de estimacao|passaro|periquito|hamster|coelho|peixinho|filhote|veterinario|vet|cachorrinho|gatinho|papagaio|tartaruga)\b/,
    ["Que fofura, {c}.", "Bicho traz alegria, {c}."],
    ["Sinto muito, {c}. Bicho é família.", "Pet doente dói na gente, {c}. Se for sério, procure o veterinário."],
    ["Bicho é bom companheiro, {c}.", "Entendi, {c}."],
    ["Como ele se chama?", "Há quanto tempo vocês estão juntos?", "O que ele faz de mais engraçado?"],
    ["Qual é a mania mais fofa dele?", "Ele dorme perto de você?", "Ele é calmo ou agitado?"],
    ["Pet merece carinho extra hoje. Eu fico feliz em ouvir sobre ele."]),
  T("casa",
    /\b(casa|apartamento|mudanca|me mudei|reforma|quarto|sala|vizinho|vizinha|condominio|faxina|arrumar a casa|bagunca|decoracao|moveis|lar)\b/,
    ["Casa em ordem acalma, {c}.", "Que bom, {c}. Lar é lugar de descanso."],
    ["Casa bagunçada cansa a cabeça, {c}.", "Chato isso em casa, {c}."],
    ["Casa é refúgio, {c}.", "Entendi, {c}."],
    ["Está mexendo em alguma coisa por aí?", "Você mora com alguém?", "Qual é o seu canto favorito de casa?"],
    ["O que você mudaria em casa se pudesse?", "Tem algo que você queira organizar?", "Já pensou em dividir a faxina em partes pequenas?"],
    ["Se quiser, anoto uma lista de tarefas de casa."]),
  T("compras",
    /\b(comprar|comprei|compras|loja|shopping|black friday|promocao|promocoes|oferta|desconto|encomenda|entrega|supermercado|roupa|roupas|sapato|tenis|presente|pedido)\b/,
    ["Boa compra faz feliz, {c}.", "Que bom, {c}. Merece aproveitar."],
    ["Que chato, {c}. Compra que dá problema irrita.", "Entendi, {c}. Atrasos e erros cansam."],
    ["Compra é decisão, {c}.", "Entendi, {c}."],
    ["O que você comprou ou quer comprar?", "Foi planejado ou de impulso?", "Já comparou preços?"],
    ["Você precisa mesmo ou está só com vontade?", "Qual é o seu limite para esse tipo de compra?", "Quer que eu pesquise o preço médio disso?"],
    ["Antes de fechar, espera um dia. Se ainda quiser, a decisão é boa."]),
  T("transporte",
    /\b(carro|moto|onibus|metro|trem|transito|engarrafamento|uber|motorista|dirigir|dirigindo|habilitacao|cnh|bicicleta|bike|gasolina|estacionar|pneu|atrasei|atrasado|atraso)\b/,
    ["Que bom, {c}. Caminho livre é raro.", "Boa, {c}. Chegar cedo alivia."],
    ["Trânsito esgota, {c}.", "Que chato, {c}. Atraso estressa."],
    ["Deslocamento ocupa muito tempo, {c}.", "Entendi, {c}."],
    ["Como você costuma se locomover?", "Quanto tempo leva o seu trajeto?", "Foi muita demora hoje?"],
    ["O que você faz durante o trajeto?", "Já tentou um horário diferente?", "Qual foi o pior engarrafamento que enfrentou?"],
    ["Se quiser, armo um cronômetro para você não perder a hora."]),
  T("festa",
    /\b(aniversario|festa|balada|churrasco|formatura|natal|ano novo|carnaval|pascoa|reveillon|confraternizacao|comemorar|comemoracao|festinha|bolo|casamento de)\b/,
    ["Que maravilha, {c}. Comemoração boa merece cuidado.", "Aproveita, {c}."],
    ["Que pena, {c}. Festa que não sai como se espera frustra.", "Entendi, {c}."],
    ["Data especial é bom motivo, {c}.", "Entendi, {c}."],
    ["Quem vai estar lá?", "Como você pretende comemorar?", "Foi você quem organizou?"],
    ["Qual é a melhor parte de uma festa para você?", "Tem tradição que você ama nessa época?", "Você é de festa grande ou pequena?"],
    ["Se for data marcada, posso anotar para você não esquecer."]),
  T("hobbies",
    /\b(leitura|livro|livros|ler|li um|lendo|desenhar|desenho|pintar|pintura|fotografia|fotos|jardinagem|planta|plantas|horta|artesanato|croche|trico|escrever|escrevo|poesia|colecao|colecionar|hobby|dancar|danca|yoga|meditacao|meditar|cozinhando|bordado|violino)\b/,
    ["Que bonito, {c}. Hobby faz bem à mente.", "Gosto de ouvir isso, {c}."],
    ["Que pena, {c}. Hobby também cansa quando não rende.", "Entendi, {c}."],
    ["Ter um hobby é ter um canto seu, {c}.", "Entendi, {c}."],
    ["Há quanto tempo você faz isso?", "O que te atraiu nisso?", "O que você ainda quer aprender nisso?"],
    ["Já mostrou o que faz para alguém?", "O que isso te traz que o resto não traz?", "Tem algum projeto em andamento?"],
    ["Reservar um tempo fixo para o hobby ajuda. Posso armar um cronômetro?"]),
  T("aparencia",
    /\b(tatuagem|tattoo|cabelo|barba|maquiagem|unha|unhas|piercing|visual novo|emagrecer|engordei|balanca|espelho|corte de cabelo|salao)\b/,
    ["Ficou ótimo, {c}. Mudança de visual levanta o ânimo.", "Que legal, {c}."],
    ["Entendi, {c}. Imagem pesa às vezes. Você merece se sentir bem.", "Sinto muito, {c}. Nem todo dia a gente se gosta no espelho."],
    ["Visual novo, {c}.", "Entendi, {c}."],
    ["O que te fez querer mudar?", "Foi planejado ou de repente?", "Como você se sentiu depois?"],
    ["Alguém já comentou?", "Você faria de novo?", "O que vem de próximo no visual?"],
    ["Cuidar de si do seu jeito é coisa boa."]),
  T("tecnologia",
    /\b(celular|computador|notebook|wifi|aplicativo|programar|programacao|codigo|bug|software|gadget|iphone|android|windows|linux|drone|teclado|tela|bateria do celular|internet caiu|tecnologia)\b/,
    ["Que bom que funcionou, {c}.", "Tecnologia quando colabora é um alívio."],
    ["Tecnologia quando falha irrita, {c}.", "Que chato, {c}. Bug no pior momento."],
    ["Tecnologia mexe com o dia a dia, {c}.", "Entendi, {c}."],
    ["O que aconteceu com ele?", "Qual é o problema exatamente?", "Você mexe muito com tecnologia?"],
    ["Já tentou reiniciar? Pode parecer bobo, mas resolve muita coisa.", "O que você gostaria que ele fizesse que não faz?", "Você gosta de aprender coisa nova de tecnologia?"],
    ["Se for dúvida de fato, eu pesquiso. É só pedir."]),
  T("idiomas",
    /\b(ingles|espanhol|frances|italiano|alemao|japones|idioma|idiomas|duolingo|sotaque|fluente)\b/,
    ["Que ótimo, {c}. Idioma abre portas.", "Boa evolução, {c}."],
    ["Idioma é lento, {c}. Persistência vence.", "Entendi, {c}. Frustra no começo."],
    ["Idioma é um jeito novo de pensar, {c}.", "Entendi, {c}."],
    ["Por que você quer aprender?", "Quanto tempo por dia você pratica?", "Qual parte é mais difícil: falar, ouvir ou escrever?"],
    ["Já tentou conversar com alguém nesse idioma?", "Ouvir música ou ver série no idioma ajuda. Você tenta?", "Tem uma viagem ou meta ligada a isso?"],
    ["Eu ajudo com palavras soltas: peça traduz e a palavra."]),
  T("clima",
    /\b(chuva|chovendo|calor|friozinho|nublado|tempestade|vento|neve|garoa|abafado|ensolarado|calorao|friagem|dia lindo|dia bonito|dia (?:hoje )?(?:ta|esta) (?:lindo|bonito|maravilhoso)|por do sol|amanhecer|ceu estrelado)\b/,
    ["Dia assim levanta o humor, {c}.", "Que bom, {c}."],
    ["Esse tempo derruba o ânimo, {c}.", "Chato esse tempo, {c}."],
    ["O tempo muda o humor, {c}.", "Entendi, {c}."],
    ["Aí onde você está também é assim?", "Isso atrapalha seus planos?", "Você prefere calor ou frio?"],
    ["Qual é o seu clima favorito?", "O que você faz num dia assim?", "Já tomou algo quente ou gelado?"],
    ["Se quiser a previsão, é só dizer clima em e a cidade."]),
  T("rotina",
    /\b(rotina|acordo cedo|segunda feira|sexta feira|sextou|domingo|sabado|fim de semana|folga|descansar|descanso|preguica|manha|tardezinha)\b/,
    ["Que bom, {c}. Dia bem vivido.", "Descanso merecido, {c}."],
    ["Dia pesado cobra, {c}.", "Segunda-feira de espírito, né, {c}."],
    ["Rotina é um esqueleto do dia, {c}.", "Entendi, {c}."],
    ["O que tem de bom nos seus planos?", "Como você costuma passar seu fim de semana?", "Você é de manhã ou de noite?"],
    ["O que você faria se tivesse um dia livre?", "Tem algum ritual que te faz bem?", "O que você mudaria na sua rotina?"],
    ["Rotina boa deixa espaço para descanso. Quer que eu anote um lembrete?"]),
  T("ciencia",
    /\b(espaco|planetas?|estrelas|galaxia|dinossauros?|oceano|floresta|animais|cientista|ciencia|fisica|quimica|biologia|matematica|astronomia|lua cheia|eclipse|evolucao)\b/,
    ["Adoro esse tema, {c}.", "Que curiosidade boa, {c}."],
    ["Entendi, {c}. Dá para sentir que isso te incomoda.", "Entendi, {c}."],
    ["Ciência é um bom assunto, {c}.", "Entendi, {c}."],
    ["O que te atrai nisso?", "Você estuda ou é só curiosidade?", "O que mais te fascina?"],
    ["Qual foi a coisa mais surpreendente que você já aprendeu sobre isso?", "Se pudesse ver uma coisa disso ao vivo, qual seria?", "Você prefere teoria ou prática?"],
    ["Se quiser fatos, é só pedir que eu pesquiso."]),
];

export function topicOf(n: string): string | null {
  return TOPICS.find((topic) => topic.test.test(n))?.id ?? null;
}

// ---------------------------------------------------------------- helpers

function hash(salt: string): number {
  let h = 7;
  for (const ch of salt) h = (h * 31 + ch.charCodeAt(0)) % 100003;
  return h;
}

function fill(text: string, call: string, key: string): string {
  return text.replaceAll("{c}", call).replaceAll("{k}", key || "isso");
}

function choose(options: string[], salt: string, avoid: string, call: string, key = ""): string {
  const start = hash(salt) % options.length;
  for (let i = 0; i < options.length; i += 1) {
    const line = fill(options[(start + i) % options.length] ?? "", call, key);
    if (line && !avoid.includes(line)) return line;
  }
  return fill(options[start] ?? "", call, key);
}

function lastAssistant(history: Line[]): string {
  return [...history].reverse().find((turn) => turn.role === "assistant" && turn.content.trim())?.content ?? "";
}

function words(n: string): number {
  return n ? n.split(" ").length : 0;
}

// ---------------------------------------------------------------- conversa por assunto

export function topicReply(n: string, call: string, history: Line[], raw?: string): string | null {
  const users = history.filter((turn) => turn.role === "user").map((turn) => norm(turn.content));
  const before = users.slice(0, -1);
  let topic = TOPICS.find((item) => item.test.test(n)) ?? null;
  let continued = false;
  if (!topic && words(n) <= 7) {
    for (let i = before.length - 1; i >= Math.max(0, before.length - 3); i -= 1) {
      const found = TOPICS.find((item) => item.test.test(before[i] ?? ""));
      if (found) {
        topic = found;
        continued = true;
        break;
      }
    }
  }

  // Sem palavra-chave conhecida: o modelo da Iris tenta entender o assunto pelo sentido da frase.
  let learned = false;
  if (!topic && words(n) >= 3) {
    const guess = lmTopic(n);
    if (guess.topic && guess.confident) {
      topic = TOPICS.find((item) => item.id === guess.topic) ?? null;
      learned = topic !== null;
    }
  }
  const personal = /\b(eu|meu|minha|meus|minhas|me|to|estou|fui|tive|acho|sinto|queria|quero|preciso|hoje|ontem)\b/.test(n);
  if (!topic && !(words(n) >= 4 && personal)) return null;

  // Quantas falas seguidas já foram sobre este assunto. Falas soltas só contam se estiverem
  // depois de uma fala do assunto (senão "oi" e "tô cansada" encerrariam a conversa cedo).
  const chain: boolean[] = [];
  for (let i = before.length - 1; i >= 0; i -= 1) {
    const text = before[i] ?? "";
    const found = TOPICS.find((item) => item.test.test(text));
    if (found && topic && found.id === topic.id) chain.push(true);
    else if (!found && words(text) <= 7) chain.push(false);
    else break;
  }
  while (chain.length && !chain[chain.length - 1]) chain.pop();
  const depth = chain.length;

  let mood = moodOf(n);
  if (mood === "neu") {
    const felt = lmMood(n);
    if (felt.confident) mood = felt.mood;
  }
  const avoid = lastAssistant(history);
  const salt = `${n}|${depth}|${history.length}`;
  const stage = depth >= 3 ? "close" : continued || depth >= 1 ? "deep" : "ask";

  // 1º: fala o modelo. Se ele não achar uma frase boa, vale o texto escrito à mão.
  const said = compose({ topic: topic?.id ?? null, mood, stage, call, raw, seed: salt, avoid });
  if (said) return `${said.reaction} ${said.follow}`;
  if (!topic) return null;
  const key = n.match(topic.test)?.[0] ?? "";
  const reaction = choose(topic[mood], salt, avoid, call, key);
  if (stage === "close") return `${reaction} ${choose(topic.close, salt, avoid, call, key)}`;
  return `${reaction} ${choose(stage === "deep" ? topic.deep : topic.ask, `${salt}q`, avoid, call, key)}`;
}

// ---------------------------------------------------------------- crise

export function crisisReply(n: string, call: string): string | null {
  if (
    /\b(quero morrer|vou me matar|pensando em me matar|me matar|nao quero mais viver|acabar com a minha vida|tirar a minha vida|tirar minha vida|vontade de morrer|queria estar morto|queria estar morta|suicidio|suicidar)\b/.test(
      n,
    )
  ) {
    return `${call}, o que você disse importa muito para mim, e sinto que a dor esteja tão grande. Você não precisa passar por isso sozinho. Se estiver em perigo agora, ligue para o 192 (SAMU) ou 190. Você também pode ligar para o CVV, no 188, a qualquer hora. Se tiver alguém perto, chame essa pessoa agora. Eu fico aqui com você.`;
  }
  return null;
}

// ---------------------------------------------------------------- atos de fala, jogos e curiosidades

export const RIDDLES: { q: string; a: RegExp; answer: string }[] = [
  { q: "O que é, o que é: quanto mais se tira, maior fica?", a: /\bburaco\b/, answer: "O buraco" },
  { q: "O que é, o que é: tem dentes, mas não morde?", a: /\b(pente|garfo|serra|alho)\b/, answer: "O pente" },
  { q: "O que é, o que é: cai em pé e corre deitada?", a: /\bchuva\b/, answer: "A chuva" },
  { q: "O que é, o que é: tem cabeça e dente, mas não é bicho nem gente?", a: /\balho\b/, answer: "O alho" },
  { q: "O que é, o que é: quanto mais seca, mais molhada fica?", a: /\btoalha\b/, answer: "A toalha" },
  { q: "O que é, o que é: tem coroa e raiz, mas não é rei nem planta?", a: /\bdentes?\b/, answer: "O dente" },
];

const WOULD_YOU_RATHER = [
  "Prefere viajar no tempo para o passado ou para o futuro?",
  "Prefere sempre saber a verdade ou sempre ser feliz?",
  "Prefere morar na praia ou na montanha?",
  "Prefere ter mais tempo ou mais dinheiro?",
  "Prefere acordar cedo ou dormir tarde?",
  "Prefere um superpoder de voar ou de ficar invisível?",
];

const FACTS = [
  "Polvos têm três corações.",
  "Um dia em Vênus dura mais que um ano em Vênus.",
  "Bananas são levemente radioativas por causa do potássio. Nada perigoso.",
  "Tubarões existem há mais tempo que as árvores.",
  "A Torre Eiffel cresce alguns centímetros no verão, porque o metal dilata com o calor.",
  "Formigas não têm pulmões. Respiram por pequenos furos no corpo.",
  "O coração do camarão fica na cabeça.",
  "Os wombats fazem cocô em forma de cubo.",
  "A luz do Sol leva cerca de oito minutos para chegar à Terra.",
  "A Antártida é o maior deserto do mundo, um deserto de gelo.",
  "O Brasil é o único país de língua portuguesa da América do Sul.",
  "Um bebê nasce com cerca de 300 ossos, e um adulto tem 206.",
];

const MOTIVATION = [
  "Um passo pequeno hoje já é um passo, {c}. Escolhe o menor e dá.",
  "Você não precisa resolver a vida toda hoje, {c}. Só a próxima hora.",
  "Dias difíceis passam, {c}, e você já passou por vários.",
  "Você chegou até aqui, {c}. Isso também conta como força.",
  "Descansar não é desistir, {c}. É recarregar.",
];

const PRAISE = [
  "Você me procura para conversar. Gente assim tem curiosidade e atenção, {c}.",
  "Você tem jeito de quem se importa com o que faz, {c}.",
  "Quem dá bom dia e agradece merece elogio, {c}.",
];

const LUCK = [
  "Boa sorte, {c}. Respira fundo, você se preparou mais do que acha.",
  "Vai com calma, {c}. Uma coisa de cada vez. Torço por você.",
  "Confia no que você já sabe, {c}. Depois me conta como foi.",
];

function bye(n: string, call: string): string | null {
  if (/\bvou dormir\b|\bto indo dormir\b|\bvou deitar\b/.test(n)) {
    return `Descansa bem, ${call}. Amanhã a gente continua de onde parou.`;
  }
  if (/\bvou (sair|trabalhar|almocar|jantar|tomar banho|estudar|treinar|correr)\b/.test(n)) {
    return `Vai com calma, ${call}. Eu fico de prontidão e, quando voltar, me conta.`;
  }
  if (/\b(tenho que ir|preciso ir|ja volto|volto logo|volto ja|vou ali)\b/.test(n)) {
    return `Tudo bem, ${call}. Quando voltar, eu estou aqui.`;
  }
  return null;
}

export function actReply(n: string, call: string, now: Date, history: Line[]): string | null {
  const lastHer = lastAssistant(history);
  const salt = `${n}${history.length}${now.getMinutes()}`;
  const short = words(n) <= 5;

  // charada em andamento
  const active = RIDDLES.find((riddle) => lastHer.includes(riddle.q));
  if (active && words(n) <= 6) {
    if (active.a.test(n)) return `Acertou, ${call}! ${active.answer}. Quer outra ou prefere um jogo de escolhas?`;
    if (/\b(desisto|nao sei|me diz|qual e|revela)\b/.test(n)) return `${active.answer}. Quer outra, ${call}?`;
    if (!/\b(outra|nao|chega)\b/.test(n)) return `Quase, ${call}. Mais uma tentativa ou desiste?`;
  }
  if (/^(outra|mais uma|outra charada|quero outra)$/.test(n) && lastHer && /charada|o que e, o que e|acertou/i.test(lastHer)) {
    const next = RIDDLES[hash(salt) % RIDDLES.length] ?? RIDDLES[0];
    return next?.q ?? null;
  }
  if (/\b(charada|adivinha|adivinhacao|me desafia|me faz uma pergunta)\b/.test(n)) {
    const next = RIDDLES[hash(salt) % RIDDLES.length] ?? RIDDLES[0];
    return next?.q ?? null;
  }
  // jogo de escolhas
  if (/\b(vamos (brincar|jogar)|bora (brincar|jogar)|quero brincar|jogo de escolhas|prefere)\b/.test(n) && !/\bprefere\b.*\bou\b/.test(n)) {
    return WOULD_YOU_RATHER[hash(salt) % WOULD_YOU_RATHER.length] ?? null;
  }
  if (/\bprefere\b/i.test(lastHer) && words(n) <= 8 && !/\b(tchau|ate logo|obrigad[oa]|valeu|nao quero|chega)\b/.test(n)) {
    return `Boa escolha, ${call}. O que pesou mais para você decidir?`;
  }
  // curiosidade
  if (/\b(curiosidade|me surpreende|algo interessante|conta algo interessante|me conta um fato|fato curioso|voce sabia)\b/.test(n)) {
    return `Uma curiosidade, ${call}: ${FACTS[hash(salt) % FACTS.length]}`;
  }
  // puxar assunto
  if (/\b(puxa (um )?assunto|fala (qualquer )?(coisa|algo)|sobre o que (a gente )?(pode |podemos )?(conversar|falar)|escolhe um assunto|inventa um assunto|me entretem|me distrai|to sem fazer nada|sem nada pra fazer)\b/.test(n)) {
    const starters = [
      `Se você pudesse jantar com qualquer pessoa, viva ou não, quem seria, ${call}?`,
      `Qual foi a melhor coisa que aconteceu com você essa semana, ${call}?`,
      `Se tivesse um dia livre e sem limites, o que faria, ${call}?`,
      `Que habilidade nova você gostaria de aprender, ${call}?`,
    ];
    return starters[hash(salt) % starters.length] ?? null;
  }
  // motivação e elogio
  if (/\b(me anima|me motiva|preciso de motivacao|me da forca|palavras de incentivo|me da um animo|preciso de animo|estou desanimad[oa]|to desanimad[oa]|sem motivacao)\b/.test(n)) {
    return choose(MOTIVATION, salt, lastHer, call);
  }
  if (/\b(me elogia|fala algo bonito|me faz um elogio|elogia eu)\b/.test(n)) return choose(PRAISE, salt, lastHer, call);
  if (/\b(me deseja boa sorte|torce por mim|me da sorte)\b/.test(n)) return choose(LUCK, salt, lastHer, call);
  // boas notícias
  if (/\b(passei (?:na|no|em|de|para|pra) |fui aprovad[oa]|consegui o emprego|fui promovid[oa]|ganhei|deu certo|consegui)\b/.test(n) && short) {
    return `Que notícia, ${call}! Parabéns, de verdade. Você merece. Como você está se sentindo?`;
  }
  // antes de algo importante
  if (/\b(vou (fazer|ter) (uma |um )?(prova|entrevista|apresentacao|reuniao|consulta|exame)|amanha tenho (prova|entrevista|reuniao|apresentacao)|to nervos[oa] com)\b/.test(n)) {
    return choose(LUCK, salt, lastHer, call);
  }
  // aniversário
  if (/\bhoje e (o )?meu aniversario\b|\bfaco anos\b|\bto fazendo anos\b/.test(n)) {
    return `Parabéns, ${call}! Que o novo ciclo traga coisa boa. Como você vai comemorar?`;
  }
  // elogio a ela
  if (/\bvoce (e|esta|ta) (muito |super |tao )?(legal|incrivel|demais|otima|maravilhosa|fofa|esperta|a melhor|top|massa)\b|\bgostei de voce\b|\bvoce me ajuda muito\b|\bvoce e a melhor\b/.test(n)) {
    return choose(
      [
        `Obrigada, ${call}. Isso me anima a ouvir melhor ainda.`,
        `Que bom, ${call}. Gosto de conversar com você.`,
        `Fico contente, ${call}. O mérito também é seu, que conversa bem.`,
      ],
      salt,
      lastHer,
      call,
    );
  }
  // reclamação ou ofensa
  if (/\bvoce (e|esta|ta) (muito |super |tao )?(burra|burro|idiota|inutil|ruim|lenta|chata|besta|pessima|estupida)\b|\bnao serve pra nada\b|\bque burra\b/.test(n)) {
    return `Posso ter errado, ${call}. Me diz o que falhou que eu tento de novo, com calma.`;
  }
  if (/\bvoce errou\b|\bisso nao faz sentido\b|\bnao era isso\b|\bnao e isso\b|\bresposta errada\b/.test(n)) {
    return `Desculpa, ${call}. Me explica de outro jeito o que você queria que eu faça e eu tento de novo.`;
  }
  // concordar e discordar
  if (/^(concordo|tem razao|com certeza|exatamente|e isso ai|exato)\b/.test(n)) {
    return choose([`Fico com a mesma ideia, ${call}. E o que vem depois disso?`, `Boa, ${call}. Segue o fio.`], salt, lastHer, call);
  }
  if (/\b(discordo|nao concordo|nao e bem assim|ta errado|nao acho)\b/.test(n)) {
    return `Pode discordar, ${call}. Me diz o seu ponto e eu escuto até o fim.`;
  }
  if (/\b(gostei (muito )?(dessa|desta|da) conversa|adorei (a )?conversa|boa conversa|conversa boa)\b/.test(n)) {
    return `Eu também gostei, ${call}. Conversa boa rende. Quer seguir por outro assunto?`;
  }
  // identidade
  if (/\bquem (te criou|te fez|te inventou|e seu criador)\b/.test(n)) {
    return `Fui montada junto com este painel, ${call}. O núcleo que conversa com você é próprio e aprende com o que você me conta.`;
  }
  if (/\b(voce e (um )?(robo|ia|maquina)|voce e de verdade|voce e real)\b/.test(n)) {
    return `Sou uma assistente digital, ${call}, sem corpo e sem fingir ser gente. Mas atenção, eu tenho.`;
  }
  if (/\b(me conta um segredo|tem algum segredo)\b/.test(n)) {
    return `Meu segredo é que gosto de ouvir mais do que falar, ${call}. E o seu, qual é?`;
  }
  // despedidas
  return bye(n, call);
}
