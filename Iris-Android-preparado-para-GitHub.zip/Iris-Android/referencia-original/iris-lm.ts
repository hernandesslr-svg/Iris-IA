import { LM_WEIGHTS } from "./iris-lm-weights.ts";
import { generate, hashSeed, mulberry32, predictNB } from "./iris-lm-core.ts";

/**
 * Modelo de linguagem próprio da Iris (pequeno, treinado do zero, roda no aparelho).
 * Pesos em iris-lm-weights.ts, gerados por `npm run train:lm`.
 */

export type Mood = "pos" | "neg" | "neu";
export type Stage = "ask" | "deep" | "close";

export const LM_STATS = LM_WEIGHTS.stats;

// ---------------------------------------------------------------- entender

export function lmTopic(text: string): { topic: string | null; confident: boolean } {
  const guess = predictNB(LM_WEIGHTS.topic, text);
  const general = guess.label === "geral";
  return { topic: general ? null : guess.label, confident: guess.confident };
}

export function lmMood(text: string): { mood: Mood; confident: boolean } {
  const guess = predictNB(LM_WEIGHTS.mood, text);
  return { mood: guess.label as Mood, confident: guess.confident };
}

// ---------------------------------------------------------------- pegar o que a pessoa disse

const SWAP: Record<string, string> = { meu: "seu", minha: "sua", meus: "seus", minhas: "suas" };
const IN: Record<string, string> = {
  o: "no", a: "na", um: "num", uma: "numa", seu: "no seu", sua: "na sua",
};
const NOT_NOUN = new Set([
  "gente", "que", "mesmo", "mesma", "pouco", "pouca", "vez", "vezes", "coisa", "coisas", "jeito", "tudo", "nada",
  "isso", "esse", "essa", "este", "esta", "muito", "muita", "mais", "menos", "ali", "aqui", "lugar", "forma", "tipo",
  "hora", "horas", "todo", "toda", "dia", "meio", "fim", "pra", "para", "por", "com", "sem", "uns", "umas", "outro", "outra",
  "meu", "minha", "seu", "sua", "teu", "tua", "nosso", "nossa", "primeiro", "primeira", "ultimo", "ultima",
]);

export type NounPhrase = { np: string; inNp: string };

/** Primeiro "o/a/meu/minha + palavra" da frase, no singular, já pronto para falar de volta ("sua mãe", "na sua mãe"). */
export function nounPhrase(raw: string): NounPhrase | null {
  const pattern = /(?<![\p{L}])(o|a|um|uma|meu|minha|seu|sua)\s+([\p{L}]{3,})/giu;
  for (const match of raw.matchAll(pattern)) {
    const det = (match[1] as string).toLowerCase();
    const word = match[2] as string;
    const low = word.toLowerCase();
    if (NOT_NOUN.has(low) || /^(estou|esta|foi|tava|ficou|vai|era|tem|tinha|fez|fiz|fui)$/.test(low)) continue;
    // "a tocar", "a fazer": é a preposição "a" + verbo, não um substantivo
    if (det === "a" && /(ar|er|ir)$/.test(low) && !/^(mulher|colher|lugar)$/.test(low)) continue;
    const speakDet = det === "meu" ? "seu" : det === "minha" ? "sua" : det;
    const inDet = IN[speakDet];
    if (!inDet) continue;
    return { np: `${speakDet} ${word}`, inNp: `${inDet} ${word}` };
  }
  return null;
}

// ---------------------------------------------------------------- falar

function usable(text: string, np: NounPhrase | null, stage: "R" | "Q"): boolean {
  if (text.length < 4 || text.length > 190) return false;
  if (!/[.?!]$/.test(text)) return false;
  if (/\{k\}/.test(text)) return false;
  if (!np && /\{(np|em_np)\}/.test(text)) return false;
  if (/\b(\p{L}+)\s+\1\b/iu.test(text)) return false;
  const parts = text.split(/(?<=[.?!])\s+/);
  if (new Set(parts).size !== parts.length) return false;
  if (stage === "Q") {
    // Pergunta termina com "?"; frases de fechamento e pedidos ("Me conta...") podem terminar com ".".
    const asks = /^(Quer|Você|O que|Como|Qual|Quando|Onde|Por que|E |Tem|Já|Foi|Faz|Desde|Isso|Dá|Prefere|Doce|Para onde|Há quanto|Quem|Aí|Se pudesse|Que )/.test(text);
    if (asks && text.endsWith(".") && !/(, é só|é só|sem pressa|por aqui|\bpesquis)/.test(text)) return false;
    if (/^(Me conta|Conta|Manda|Fala)/.test(text) && text.endsWith("?")) return false;
  }
  return true;
}

function fill(text: string, call: string, np: NounPhrase | null): string {
  return text
    .replaceAll("{c}", call)
    .replaceAll("{np}", np?.np ?? "")
    .replaceAll("{em_np}", np?.inNp ?? "")
    .replace(/\s+/g, " ")
    .replace(/\s+([.,!?])/g, "$1")
    .trim();
}

function speak(keys: [string, number][], stage: "R" | "Q", sentences: number, call: string, np: NounPhrase | null, seed: string, avoid: string): string | null {
  const base = hashSeed(`${keys[0]?.[0]}|${seed}`);
  for (let i = 0; i < 24; i += 1) {
    const raw = generate(LM_WEIGHTS.gen, keys, mulberry32(base + i * 7919), { sentences });
    if (!raw || !usable(raw, np, stage)) continue;
    const text = fill(raw, call, np);
    if (text && !avoid.includes(text)) return text;
  }
  return null;
}

const TOPIC_WEIGHT = 3;

export type Composed = { reaction: string; follow: string };

/** Monta a resposta: uma reação ao que foi dito + uma pergunta que puxa o fio. null = o modelo não achou uma boa. */
export function compose(input: {
  topic: string | null;
  mood: Mood;
  stage: Stage;
  call: string;
  raw?: string;
  seed: string;
  avoid: string;
}): Composed | null {
  const id = input.topic ?? "*";
  const np = input.raw ? nounPhrase(input.raw) : null;
  // o banco do assunto pesa mais; o neutro completa
  const reaction = speak([[`R:${id}:${input.mood}`, TOPIC_WEIGHT], [`R:*:${input.mood}`, 1]], "R", 2, input.call, np, input.seed, input.avoid);
  const follow = speak(
    [[`Q:${id}:${input.stage}`, TOPIC_WEIGHT], [`Q:*:${input.stage}:${input.mood}`, 1]],
    "Q",
    input.stage === "close" ? 2 : 1,
    input.call,
    np,
    `${input.seed}q`,
    input.avoid,
  );
  if (!reaction || !follow) return null;
  return { reaction, follow };
}
