import { norm } from "./iris-local.ts";

export type Lesson = {
  id: string;
  topic: string;
  keys: string[];
  say: string;
  source: "rede" | "conversa";
  at: number;
  hits: number;
};

const STOP = new Set([
  "que",
  "como",
  "qual",
  "quais",
  "para",
  "pra",
  "com",
  "uma",
  "por",
  "dos",
  "das",
  "nao",
  "sim",
  "voce",
  "seu",
  "sua",
  "isso",
  "essa",
  "esse",
  "esta",
  "estou",
  "quero",
  "pode",
  "sobre",
  "quando",
  "onde",
  "porque",
  "pelo",
  "pela",
  "mais",
  "muito",
  "bem",
  "aqui",
  "meu",
  "minha",
  "iris",
  "pesquisar",
  "pesquisa",
  "fale",
  "fala",
]);

export function lessonTokens(raw: string): string[] {
  const unique: string[] = [];
  for (const word of norm(raw).split(" ")) {
    if (word.length < 4 || STOP.has(word) || unique.includes(word)) continue;
    unique.push(word);
    if (unique.length >= 8) break;
  }
  return unique;
}

export function isLesson(value: unknown): value is Lesson {
  if (!value || typeof value !== "object") return false;
  const lesson = value as Lesson;
  return (
    typeof lesson.id === "string" &&
    typeof lesson.topic === "string" &&
    typeof lesson.say === "string" &&
    Array.isArray(lesson.keys) &&
    (lesson.source === "rede" || lesson.source === "conversa")
  );
}

export function recallLesson(raw: string, lessons: Lesson[]): Lesson | null {
  const words = lessonTokens(raw);
  const n = norm(raw);
  if (n.length < 4) return null;
  let best: { lesson: Lesson; score: number } | null = null;
  for (const lesson of lessons) {
    const topic = norm(lesson.topic);
    let score = 0;
    if (topic.length >= 4 && (n === topic || n.includes(topic) || topic.includes(n))) score += 5;
    for (const word of words) {
      if (lesson.keys.includes(word) || topic.includes(word)) score += 1;
    }
    if (!best || score > best.score) best = { lesson, score };
  }
  if (!best || best.score < 2) return null;
  return best.lesson;
}

export function learnLesson(
  lessons: Lesson[],
  input: { topic: string; say: string; source: "rede" | "conversa" },
): Lesson[] {
  const topic = input.topic.trim().slice(0, 140);
  const say = input.say.trim().slice(0, 420);
  const keys = lessonTokens(`${topic} ${say}`);
  if (topic.length < 3 || say.length < 8 || keys.length === 0) return lessons;
  const topicKey = norm(topic);
  const same = lessons.find((lesson) => norm(lesson.topic) === topicKey);
  const next = same
    ? lessons.map((lesson) =>
        lesson.id === same.id
          ? { ...lesson, say, keys, source: input.source, at: Date.now(), hits: lesson.hits + 1 }
          : lesson,
      )
    : [
        {
          id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
          topic,
          keys,
          say,
          source: input.source,
          at: Date.now(),
          hits: 1,
        },
        ...lessons,
      ];
  return next.sort((a, b) => b.at - a.at).slice(0, 60);
}

export function phraseRecall(lesson: Lesson, call: string): string {
  const body = lesson.say.replace(/^Pesquisei\.\s*/i, "").replace(/^Abri a página\.\s*/i, "");
  if (lesson.source === "rede") return `Disso eu já aprendi na rede, ${call}. ${body}`;
  return `Disso eu lembro da conversa, ${call}. ${body}`;
}

export function taughtFact(raw: string): string | null {
  const n = norm(raw);
  if (n.length < 8) return null;
  if (
    /^(eu (gosto|nao gosto|moro|trabalho|estudo|tenho|sou|prefiro)|meu nome e|minha (comida|cor|cidade)|lembra que|guarda que|aprende que)\b/.test(
      n,
    )
  ) {
    return raw.trim().slice(0, 180);
  }
  return null;
}

export function shouldRememberTalk(user: string, answer: string): boolean {
  const n = norm(user);
  const said = norm(answer);
  if (n.length < 8 || answer.trim().length < 12) return false;
  if (/\b(morrer|me matar|suicid\w*|nao quero mais viver)\b/.test(n)) return false;
  if (/^(oi|ola|bom dia|boa tarde|boa noite|obrigad|tchau|ok|certo|ajuda|tudo bem|como vai|entendi|valeu)/.test(n)) {
    return false;
  }
  if (/nao peguei|nao achei|tropec|deixo quieto|anotado|minha funcao e esta|ainda nao aprendi|isso e conversa|nao pesquiso|pode repetir|estou te ouvindo/.test(said)) return false;
  return true;
}
