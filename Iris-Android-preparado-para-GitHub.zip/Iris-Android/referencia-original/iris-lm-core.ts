import { norm } from "./iris-local.ts";

/**
 * Núcleo do modelo da Iris, escrito do zero e sem dependências:
 *
 *  1. ENTENDER — classificador Naive Bayes treinado sobre palavras, pares de palavras e
 *     pedaços de palavra. Aprende "assunto" e "humor" a partir de exemplos, e por isso
 *     reconhece formas que nunca viu inteiras (cansaço, cansado, cansativo).
 *  2. FALAR — modelo de linguagem de n-gramas (trigramas com recuo), condicionado ao
 *     assunto e ao humor. Aprende a montar frases palavra por palavra a partir do texto
 *     de treino, em vez de repetir frases prontas.
 *
 * É pequeno de propósito: é o começo. Mais texto de treino = modelo melhor.
 */

// ---------------------------------------------------------------- entender (Naive Bayes)

export type NBModel = {
  classes: string[];
  prior: number[];
  total: number[];
  vocab: number;
  alpha: number;
  /** palavra → [classe, contagem, classe, contagem, ...] */
  feats: Record<string, number[]>;
  /** diferença mínima (por traço) entre 1º e 2º lugar para considerar uma resposta firme */
  minGap: number;
};

/** Quais "traços" o classificador olha. Ajustado nos testes de treino. */
export const featureOptions = { bigrams: true, chars: true, minChar: 4, maxChar: 5, minWord: 4 };

export function features(text: string): string[] {
  const tokens = norm(text).split(/[^a-z0-9]+/).filter(Boolean);
  const out = new Set<string>();
  tokens.forEach((token, i) => {
    if (token.length >= 2) out.add(`w:${token}`);
    const next = tokens[i + 1];
    if (featureOptions.bigrams && next) out.add(`b:${token}_${next}`);
    if (featureOptions.chars && token.length >= featureOptions.minWord) {
      const word = `^${token}$`;
      for (let size = featureOptions.minChar; size <= featureOptions.maxChar; size += 1) {
        for (let at = 0; at + size <= word.length; at += 1) out.add(`c:${word.slice(at, at + size)}`);
      }
    }
  });
  return [...out];
}

export function trainNB(
  examples: { text: string; label: string }[],
  options: { minCount?: number; alpha?: number } = {},
): NBModel {
  const minCount = options.minCount ?? 2;
  const alpha = options.alpha ?? 2;
  const classes = [...new Set(examples.map((example) => example.label))].sort();
  const index = new Map(classes.map((label, i) => [label, i]));
  const counts = new Map<string, number[]>();
  const perClass = new Array<number>(classes.length).fill(0);
  for (const example of examples) {
    const c = index.get(example.label) ?? 0;
    perClass[c] = (perClass[c] ?? 0) + 1;
    for (const feature of features(example.text)) {
      let row = counts.get(feature);
      if (!row) {
        row = new Array<number>(classes.length).fill(0);
        counts.set(feature, row);
      }
      row[c] = (row[c] ?? 0) + 1;
    }
  }
  const feats: Record<string, number[]> = {};
  const total = new Array<number>(classes.length).fill(0);
  const keys = [...counts.keys()].sort();
  for (const feature of keys) {
    const row = counts.get(feature) as number[];
    if (row.reduce((a, b) => a + b, 0) < minCount) continue;
    const sparse: number[] = [];
    row.forEach((count, c) => {
      if (count > 0) {
        sparse.push(c, count);
        total[c] = (total[c] ?? 0) + count;
      }
    });
    feats[feature] = sparse;
  }
  const n = examples.length;
  return {
    classes,
    prior: perClass.map((count) => Math.log((count + 1) / (n + classes.length))),
    total,
    vocab: Object.keys(feats).length,
    alpha,
    feats,
    minGap: 0,
  };
}

export type NBGuess = { label: string; gap: number; known: number; confident: boolean; scores: number[] };

export function predictNB(model: NBModel, text: string): NBGuess {
  const scores = [...model.prior];
  let known = 0;
  for (const feature of features(text)) {
    const sparse = model.feats[feature];
    if (!sparse) continue;
    known += 1;
    const have = new Map<number, number>();
    for (let i = 0; i < sparse.length; i += 2) have.set(sparse[i] as number, sparse[i + 1] as number);
    for (let c = 0; c < model.classes.length; c += 1) {
      const denom = (model.total[c] ?? 0) + model.alpha * model.vocab;
      scores[c] = (scores[c] ?? 0) + Math.log(((have.get(c) ?? 0) + model.alpha) / denom);
    }
  }
  let best = 0;
  for (let c = 1; c < scores.length; c += 1) if ((scores[c] as number) > (scores[best] as number)) best = c;
  let second = -Infinity;
  for (let c = 0; c < scores.length; c += 1) if (c !== best && (scores[c] as number) > second) second = scores[c] as number;
  const gap = known ? ((scores[best] as number) - second) / known : 0;
  return {
    label: model.classes[best] ?? "",
    gap,
    known,
    confident: known >= 3 && gap >= model.minGap,
    scores,
  };
}

// ---------------------------------------------------------------- falar (n-gramas)

export type GenTable = { o3: Record<string, number[]>; o2: Record<string, number[]> };
export type GenModel = {
  vocab: string[];
  tables: Record<string, GenTable>;
  /** frases do treino (para saber se o que ela disse é novo) */
  known: string[];
};

export const START = "<s>";
export const END = "</s>";
const PUNCT = new Set([".", ",", "!", "?", ";", ":", "…"]);

export function tokenizeGen(text: string): string[] {
  return text.match(/\{[a-z_]+\}|[\p{L}\p{N}'’-]+|[.,!?;:…]/gu) ?? [];
}

export function detokenize(tokens: string[]): string {
  let out = "";
  for (const token of tokens) {
    if (!out) out = token;
    else if (PUNCT.has(token)) out += token;
    else out += ` ${token}`;
  }
  return out;
}

export type GenSample = { key: string; broad: string; text: string };

export function trainGen(samples: GenSample[]): GenModel {
  const vocab: string[] = [START, END];
  const ids = new Map<string, number>([[START, 0], [END, 1]]);
  const id = (token: string): number => {
    let found = ids.get(token);
    if (found === undefined) {
      found = vocab.length;
      vocab.push(token);
      ids.set(token, found);
    }
    return found;
  };
  type Raw = { o3: Map<string, Map<number, number>>; o2: Map<string, Map<number, number>> };
  const raw = new Map<string, Raw>();
  const bump = (map: Map<string, Map<number, number>>, ctx: string, next: number) => {
    let row = map.get(ctx);
    if (!row) {
      row = new Map();
      map.set(ctx, row);
    }
    row.set(next, (row.get(next) ?? 0) + 1);
  };
  for (const sample of samples) {
    const tokens = [0, 0, ...tokenizeGen(sample.text).map(id), 1];
    for (const key of new Set([sample.key, sample.broad])) {
      let table = raw.get(key);
      if (!table) {
        table = { o3: new Map(), o2: new Map() };
        raw.set(key, table);
      }
      for (let i = 2; i < tokens.length; i += 1) {
        bump(table.o3, `${tokens[i - 2]},${tokens[i - 1]}`, tokens[i] as number);
        bump(table.o2, `${tokens[i - 1]}`, tokens[i] as number);
      }
    }
  }
  const flat = (map: Map<string, Map<number, number>>): Record<string, number[]> => {
    const out: Record<string, number[]> = {};
    for (const ctx of [...map.keys()].sort()) {
      const row = [...(map.get(ctx) as Map<number, number>).entries()].sort((a, b) => a[0] - b[0]);
      out[ctx] = row.flatMap(([next, count]) => [next, count]);
    }
    return out;
  };
  const tables: Record<string, GenTable> = {};
  for (const key of [...raw.keys()].sort()) {
    const table = raw.get(key) as Raw;
    tables[key] = { o3: flat(table.o3), o2: flat(table.o2) };
  }
  return { vocab, tables, known: [...new Set(samples.map((sample) => sample.text))].sort() };
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(text: string): number {
  let h = 2166136261;
  for (const ch of text) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  return h >>> 0;
}

/**
 * Junta as opções de vários bancos (cada um com um peso). Usa sempre o contexto MAIS LONGO que
 * algum banco conheça (duas palavras); só recua para uma palavra se nenhum conhecer. Misturar as
 * duas ordens quebrava as frases no meio.
 */
function mergedRow(model: GenModel, keys: [string, number][], a: number, b: number): number[] | undefined {
  for (const order of ["o3", "o2"] as const) {
    const sum = new Map<number, number>();
    for (const [key, weight] of keys) {
      const table = model.tables[key];
      const row = table ? (order === "o3" ? table.o3[`${a},${b}`] : table.o2[`${b}`]) : undefined;
      if (!row) continue;
      for (let i = 0; i < row.length; i += 2) {
        const next = row[i] as number;
        sum.set(next, (sum.get(next) ?? 0) + (row[i + 1] as number) * weight);
      }
    }
    if (sum.size) return [...sum.entries()].sort((x, y) => x[0] - y[0]).flatMap(([next, count]) => [next, count]);
  }
  return undefined;
}

function sample(row: number[], rand: () => number, temperature: number): number {
  const weights: number[] = [];
  let sum = 0;
  for (let i = 1; i < row.length; i += 2) {
    const w = Math.pow(row[i] as number, 1 / temperature);
    weights.push(w);
    sum += w;
  }
  let pick = rand() * sum;
  for (let i = 0; i < weights.length; i += 1) {
    pick -= weights[i] as number;
    if (pick <= 0) return row[i * 2] as number;
  }
  return row[(weights.length - 1) * 2] as number;
}

/**
 * Gera um texto de até `sentences` frases, palavra por palavra. `keys` são os bancos que falam
 * ao mesmo tempo, cada um com seu peso (ex.: o do assunto pesa mais que o neutro).
 */
export function generate(
  model: GenModel,
  keys: [string, number][],
  rand: () => number,
  options: { temperature?: number; sentences?: number; maxTokens?: number } = {},
): string {
  const temperature = options.temperature ?? 1;
  const maxSentences = options.sentences ?? 2;
  const maxTokens = options.maxTokens ?? 34;
  const out: number[] = [];
  let a = 0;
  let b = 0;
  let done = 0;
  for (let step = 0; step < maxTokens; step += 1) {
    const row = mergedRow(model, keys, a, b);
    if (!row) break;
    const next = sample(row, rand, temperature);
    if (next === 1) return detokenize(out.map((i) => model.vocab[i] as string));
    out.push(next);
    const token = model.vocab[next] as string;
    if (token === "." || token === "?" || token === "!") {
      done += 1;
      if (done >= maxSentences) return detokenize(out.map((i) => model.vocab[i] as string));
    }
    a = b;
    b = next;
  }
  return "";
}

/** Média do log da probabilidade de cada palavra (mais alto = mais natural para o modelo). */
export function avgLogProb(model: GenModel, keys: [string, number][], text: string): number {
  const index = new Map(model.vocab.map((token, i) => [token, i]));
  const ids = [0, 0, ...tokenizeGen(text).map((token) => index.get(token) ?? -1), 1];
  let sum = 0;
  let n = 0;
  for (let i = 2; i < ids.length; i += 1) {
    const row = mergedRow(model, keys, ids[i - 2] as number, ids[i - 1] as number);
    let p = 1e-4;
    if (row) {
      let all = 0;
      let hit = 0;
      for (let j = 0; j < row.length; j += 2) {
        all += row[j + 1] as number;
        if (row[j] === ids[i]) hit = row[j + 1] as number;
      }
      p = Math.max(hit / all, 1e-4);
    }
    sum += Math.log(p);
    n += 1;
  }
  return n ? sum / n : -10;
}

export type LMWeights = {
  topic: NBModel;
  mood: NBModel;
  gen: GenModel;
  /** números medidos no treino (frases de prova que o modelo nunca viu) */
  stats: Record<string, number>;
};
