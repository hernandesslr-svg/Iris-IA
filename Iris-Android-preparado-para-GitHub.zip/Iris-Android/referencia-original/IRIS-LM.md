# Modelo de linguagem da Iris

A Iris tem um modelo de linguagem **próprio**, pequeno, treinado do zero neste projeto. Ele roda no aparelho, sem internet e sem depender de nenhuma outra IA.

## O que ele faz

1. **Entender** (`iris-lm-core.ts`): um classificador (Naive Bayes) aprende, a partir de exemplos, o **assunto** (35 assuntos + "geral") e o **humor** (bom, ruim, neutro) de uma frase. Olha palavras, pares de palavras e pedaços de palavra, então reconhece formas que nunca viu inteiras.
2. **Pegar o que você disse** (`iris-lm.ts`): extrai "sua mãe", "o jogo", "a prova" e pergunta sobre isso com a gramática certa ("na sua mãe", "no jogo").
3. **Falar** (`iris-lm-core.ts`): um modelo de n-gramas (trigramas com recuo) aprende a montar frases palavra por palavra a partir do texto de treino, falando junto o banco do assunto e o banco neutro do humor. Cada resposta é validada (frase inteira, pontuação, sem repetição) antes de sair.

As palavras-chave de `iris-topics.ts` continuam na frente (são exatas e instantâneas). O modelo entra quando elas não reconhecem a frase, e escolhe as palavras da resposta.

## Treinar

```
npm run train:lm            # treina e grava src/lib/iris-lm-weights.ts
LM_EXPLORE=1 npm run train:lm   # só compara variações do classificador
```

O treino confere que nenhuma frase de prova (`iris-lm-eval.ts`) aparece no texto de treino e imprime a medida em frases que o modelo nunca viu.

## Fazer ela aprender mais

Tudo é texto. Edite e rode `npm run train:lm`:

| O que você quer | Onde |
| --- | --- |
| Novas palavras de um assunto | `TOPIC_WORDS` / `TOPIC_WORDS_EXTRA` em `iris-lm-corpus.ts` |
| Frases naturais de um assunto | `TOPIC_SENTENCES` / `TOPIC_SENTENCES_EXTRA`, ou `iris-chat-cases.ts` |
| Um assunto novo | uma entrada em `TOPICS` (`iris-topics.ts`) + palavras e frases acima |
| Jeito de reagir e perguntar | `reactions` e `ask`/`deep`/`close` de cada assunto, `GENERIC_*` e `NP_QUESTIONS` |
| Humor | `MOOD_SENTENCES` / `MOOD_SENTENCES_EXTRA` |
| Frases para medir de verdade | `iris-lm-eval.ts` (nunca vão para o treino) |

## Limites (é o começo)

- É estatístico: não raciocina, não tem noção de verdade e não guarda o fio de conversas longas. Frases de assuntos que ela não conhece caem numa resposta neutra.
- O gerador recombina o que aprendeu. Quanto mais e melhor o texto de treino, melhor ela fala.
- Fatos do mundo continuam vindo da pesquisa na rede, não do modelo.
