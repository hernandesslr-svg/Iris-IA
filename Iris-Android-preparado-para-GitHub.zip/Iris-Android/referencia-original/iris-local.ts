export type Note = { id: string; text: string };

export type Effect =
  | { kind: "rename"; name: string }
  | { kind: "note-add"; text: string }
  | { kind: "note-clear" }
  | { kind: "note-delete"; index: number }
  | { kind: "timer"; seconds: number; label: string }
  | { kind: "timer-clear" }
  | { kind: "chat-clear" }
  | { kind: "voice"; on: boolean };

export type LocalHit = {
  say?: string;
  effects: Effect[];
  weather?: { city?: string };
};

export type CommandContext = {
  callsign: string;
  now: Date;
  notes: Note[];
  timers: number;
  online: boolean;
  cores: number;
  lang: string;
  link: string;
};

const HELLO =
  "Cuido da hora, do clima, das notas, dos cronômetros e das contas. O que pesquiso e o que me contam, eu aprendo e guardo no núcleo.";

export function helloText(callsign: string): string {
  return `Às suas ordens, ${callsign}. ${HELLO}`;
}

export function dutiesText(callsign: string): string {
  return `${callsign}, minha função é esta: hora, clima, notas, cronômetro, contas, conversões e conversa. Quando não sei, pesquiso e aprendo. Se pedir para abrir, abro a página.`;
}

export function aboutIris(raw: string): boolean {
  const n = norm(raw);
  if (/\bfunc(?:ao|oes)\s+(?:do|da|de|dos|das)\s+(?!voce\b|iris\b|dela\b)/.test(n)) return false;
  if (/\bfunc(?:ao|oes)\b/.test(n)) return true;
  if (/\b(sua|suas|seu)\s+(papel|trabalho|habilidade|habilidades|capacidade|capacidades)\b/.test(n)) return true;
  if (/\bo que voce (faz|pode fazer|sabe fazer|consegue fazer|consegue|pode)\b/.test(n)) return true;
  if (/\b(para que voce serve|pra que voce serve|o que voce sabe fazer)\b/.test(n)) return true;
  if (/^(ajuda|help|comandos)$/.test(n)) return true;
  return false;
}

export function norm(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/[?!.,;:]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function hearOnce(value: string): string {
  const chunk = value.replace(/\s+/g, " ").trim();
  if (!chunk) return "";
  const words = chunk.split(" ").filter(Boolean);
  for (let size = 1; size <= Math.floor(words.length / 2); size += 1) {
    if (words.length % size !== 0) continue;
    const piece = words.slice(0, size).join(" ");
    let same = true;
    for (let turn = 1; turn < words.length / size; turn += 1) {
      if (words.slice(turn * size, (turn + 1) * size).join(" ") !== piece) {
        same = false;
        break;
      }
    }
    if (same) return piece;
  }
  const once: string[] = [];
  for (const word of words) {
    if (once[once.length - 1]?.toLowerCase() === word.toLowerCase()) continue;
    once.push(word);
  }
  return once.join(" ");
}

export function joinHeard(base: string, extra: string): string {
  const left = base.replace(/\s+/g, " ").trim();
  const right = extra.replace(/\s+/g, " ").trim();
  if (!left) return hearOnce(right);
  if (!right) return hearOnce(left);
  const al = left.toLowerCase();
  const bl = right.toLowerCase();
  if (bl.startsWith(al)) return hearOnce(right);
  if (al.startsWith(bl) || al.endsWith(` ${bl}`) || al.endsWith(bl)) return hearOnce(left);
  const leftWords = al.split(" ");
  const rightWords = bl.split(" ");
  const limit = Math.min(leftWords.length, rightWords.length);
  for (let count = limit; count >= 1; count -= 1) {
    if (leftWords.slice(-count).join(" ") !== rightWords.slice(0, count).join(" ")) continue;
    const rest = right.split(" ").slice(count).join(" ");
    return hearOnce(rest ? `${left} ${rest}` : left);
  }
  return hearOnce(`${left} ${right}`);
}

export function wakeCommand(raw: string): string | null {
  const n = norm(raw);
  if (!/\biris\b/.test(n)) return null;
  return n
    .replace(/^(ei|ola|oi|hey|e ai|psiu)\s+/, "")
    .replace(/\biris\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function formatNum(value: number): string {
  const rounded = Math.round(value * 1000) / 1000;
  return rounded.toLocaleString("pt-BR");
}

export function formatRemain(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function clockParts(now: Date): { time: string; date: string } {
  return {
    time: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
    date: now.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" }),
  };
}

export function weatherPhrase(code: number): string {
  if (code === 0) return "céu limpo";
  if (code <= 3) return "parcialmente nublado";
  if (code === 45 || code === 48) return "neblina";
  if (code <= 57) return "garoa";
  if (code <= 67) return "chuva";
  if (code <= 77) return "neve";
  if (code <= 82) return "pancadas de chuva";
  if (code <= 86) return "pancadas de neve";
  if (code >= 95) return "trovoada";
  return "tempo instável";
}

function durationPhrase(seconds: number): string {
  if (seconds % 3600 === 0) {
    const h = seconds / 3600;
    return h === 1 ? "1 hora" : `${h} horas`;
  }
  if (seconds % 60 === 0) {
    const m = seconds / 60;
    return m === 1 ? "1 minuto" : `${m} minutos`;
  }
  return seconds === 1 ? "1 segundo" : `${seconds} segundos`;
}

function tryCalc(raw: string): string | null {
  const n = norm(raw);
  const hadVerb = /^(quanto e|quanto fica|calcule|calcula|conta|faz a conta)\b/.test(n);
  let expr = n.replace(/^(quanto e|quanto fica|calcule|calcula|conta|faz a conta)\s+/, "");
  expr = expr.replace(/[x×]/g, "*").replace(/÷/g, "/").replace(/,/g, ".");
  const pct = expr.match(/^(\d+(?:\.\d+)?)\s*%\s*de\s*(\d+(?:\.\d+)?)$/);
  if (pct) {
    const value = (Number(pct[1]) / 100) * Number(pct[2]);
    return Number.isFinite(value) ? formatNum(value) : null;
  }
  if (!/^[\d\s.+\-*/()%^]+$/.test(expr) || !/\d/.test(expr)) return null;
  if (!hadVerb && !/[+\-*/^%]/.test(expr)) return null;
  const js = expr.replace(/\^/g, "**").replace(/%/g, "/100");
  try {
    const value = Function(`"use strict"; return (${js})`)();
    if (typeof value !== "number" || !Number.isFinite(value)) return null;
    return formatNum(value);
  } catch {
    return null;
  }
}

function cleanName(value: string): string | null {
  const name = value.replace(/[^\p{L}\p{N} '\-]/gu, "").trim().slice(0, 24);
  if (name.length < 2) return null;
  return name;
}

export function interpret(raw: string, ctx: CommandContext): LocalHit | null {
  const text = raw.trim();
  const n = norm(text);
  if (!n) return null;

  if (/\b(jarvis|iron man|homem de ferro|tony stark)\b/.test(n)) {
    return {
      effects: [],
      say: "Esse nome é de um filme. Nesta casa quem atende é Iris. Às suas ordens.",
    };
  }

  if (aboutIris(n)) {
    return { effects: [], say: dutiesText(ctx.callsign) };
  }

  if (/^(limpar conversa|limpa a conversa|apagar conversa|apaga a conversa|esquecer conversa|comecar de novo|reset)$/.test(n)) {
    return { effects: [{ kind: "chat-clear" }], say: "Registro limpo. Sigo de prontidão." };
  }

  if (/^(sem voz|fica em silencio|silencio|mudo|para de falar|nao fale|cala a boca)$/.test(n)) {
    return {
      effects: [{ kind: "voice", on: false }],
      say: "Como desejar. Fico em silêncio até você pedir a voz de volta.",
    };
  }

  if (/^(com voz|pode falar|fale|ative a voz|ativa a voz|liga a voz)$/.test(n)) {
    return { effects: [{ kind: "voice", on: true }], say: "Voz restaurada." };
  }

  const rename = text.match(/^(?:me chame de|pode me chamar de|meu nome (?:é|e)|chama de)\s+(.+)$/i);
  if (rename) {
    const name = cleanName(rename[1] ?? "");
    if (!name) return { effects: [], say: "Preciso de um nome curto, só com letras." };
    return { effects: [{ kind: "rename", name }], say: `Passo a tratá-lo por ${name}.` };
  }

  if (/^(apagar notas|apaga as notas|apagar as notas|limpar notas|limpa as notas)$/.test(n)) {
    return { effects: [{ kind: "note-clear" }], say: "Notas apagadas do registro." };
  }

  const drop = n.match(/^apaga(?:r)? (?:a )?nota (\d+)$/);
  if (drop) {
    const index = Number(drop[1]);
    if (!ctx.notes[index - 1]) return { effects: [], say: "Não há nota com esse número." };
    return { effects: [{ kind: "note-delete", index }], say: `Nota ${index} removida.` };
  }

  if (/^(minhas notas|notas|ler notas|quais sao minhas notas)$/.test(n)) {
    if (ctx.notes.length === 0) return { effects: [], say: "O registro de notas está vazio." };
    const list = ctx.notes
      .slice(0, 8)
      .map((note, i) => `${i + 1}. ${note.text}`)
      .join(". ");
    const extra = ctx.notes.length > 8 ? ` E mais ${ctx.notes.length - 8}.` : "";
    return { effects: [], say: `Suas notas: ${list}.${extra}` };
  }

  const noted = text.match(/^(?:anotar|anota|nova nota|nota)\s*[:\-–]?\s+(.+)$/i);
  if (noted) {
    const body = (noted[1] ?? "").trim().slice(0, 180);
    if (!body) return { effects: [], say: "Diga o que devo anotar." };
    return {
      effects: [{ kind: "note-add", text: body }],
      say: `Anotei: ${body}. São ${ctx.notes.length + 1} no registro.`,
    };
  }

  if (/^(cancela(?:r)?|para(?:r)?) (?:o |os )?(timer|timers|cronometro|cronometros|alarme|alarmes)$/.test(n)) {
    if (ctx.timers === 0) return { effects: [], say: "Não há cronômetro armado." };
    return { effects: [{ kind: "timer-clear" }], say: "Cronômetros cancelados." };
  }

  const timed = n.match(
    /(?:cronometro|timer|alarme|contador|me avisa|avisa me|me lembra)\D{0,24}(\d+)\s*(horas?|h|minutos?|mins?|min|segundos?|segs?|seg|s)\b/,
  );
  if (timed) {
    const amount = Number(timed[1]);
    const unit = timed[2] ?? "";
    let seconds = amount;
    if (/^h/.test(unit)) seconds = amount * 3600;
    else if (/^min|^m/.test(unit)) seconds = amount * 60;
    if (!Number.isFinite(seconds) || seconds < 1 || seconds > 86400) {
      return { effects: [], say: "Consigo cronômetros de um segundo até 24 horas." };
    }
    const labelMatch = text.match(/\bpara\s+(.+)$/i);
    const label = (labelMatch?.[1] ?? "").trim().slice(0, 60);
    const tail = label ? ` Para ${label}.` : "";
    return {
      effects: [{ kind: "timer", seconds, label }],
      say: `Cronômetro armado. Aviso em ${durationPhrase(seconds)}.${tail}`,
    };
  }

  const asksTime =
    /\b(que horas sao|que hora sao|me diz as horas|me diz a hora|me fala as horas|qual e a hora|que dia e hoje|que dia e|data de hoje)\b/.test(n) ||
    /\bque hora e(?: agora| hoje)?$/.test(n) ||
    /^(hora|horas|data)$/.test(n);
  const asksWeather =
    /^(tempo|clima|previsao|temperatura)$/.test(n) ||
    /\b(como esta o tempo|como ta o tempo|qual e o clima|qual o clima|qual a temperatura|previsao do tempo)\b/.test(n) ||
    /\b(clima|previsao|temperatura)\b/.test(n) ||
    /\btempo\s+(?:em|para|pra)\b/.test(n);
  if (asksTime || asksWeather) {
    const city = n.match(/\b(?:clima|previsao|temperatura|tempo)\s+(?:em|para|pra)\s+([\p{L}][\p{L}\s-]{1,40})/u);
    const place = city?.[1]?.split(/\s+e\s+/)[0]?.trim();
    const badPlace = !place || /^(hoje|agora|ai|aqui)$/.test(place);
    const parts = clockParts(ctx.now);
    return {
      effects: [],
      say: asksTime ? `São ${parts.time}. ${parts.date}.` : undefined,
      weather: asksWeather ? { city: badPlace ? undefined : place } : undefined,
    };
  }

  if (/^(diagnostico|status|sistemas|checagem|relatorio|protocolo)$/.test(n)) {
    const rede = ctx.online ? "rede estável" : "sem rede";
    const timers = ctx.timers === 0 ? "nenhum cronômetro" : `${ctx.timers} cronômetro${ctx.timers > 1 ? "s" : ""}`;
    return {
      effects: [],
      say: `Diagnóstico: ${rede}, ${ctx.cores || "vários"} núcleos lógicos, idioma ${ctx.lang || "desconhecido"}, ${ctx.notes.length} notas, ${timers}. Meu núcleo é próprio e já está em linha.`,
    };
  }

  const math = tryCalc(text);
  if (math) return { effects: [], say: `O resultado é ${math}.` };

  if (n.length <= 32 && /^(oi|ola|eai|e ai|hey|hello|hi|bom dia|boa tarde|boa noite|iris|esta ai|ta ai)$/.test(n)) {
    const hour = ctx.now.getHours();
    const shift = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
    return { effects: [], say: `${shift}, ${ctx.callsign}. Estou em linha.` };
  }

  if (n.length <= 32 && /^(obrigad[oa]|valeu|brigado|thanks|thank you)$/.test(n)) {
    return { effects: [], say: "O prazer é meu." };
  }

  if (n.length <= 28 && /^(tchau|ate mais|ate logo|falou|encerrar)$/.test(n)) {
    return { effects: [], say: `Fico de prontidão, ${ctx.callsign}.` };
  }

  if (/^(quem e voce|o que voce e|qual e o seu nome|qual seu nome|como voce se chama)$/.test(n)) {
    return {
      effects: [],
      say: "Sou Iris. Meu núcleo é meu. O que pesquiso e o que me contam, eu aprendo. Não peço a outro modelo para pensar.",
    };
  }

  return null;
}
